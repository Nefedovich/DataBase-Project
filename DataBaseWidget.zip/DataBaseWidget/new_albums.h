#ifndef NEW_ALBUMS_H
#define NEW_ALBUMS_H

#include <QDialog>
#include <QMessageBox>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
#include <QSqlDatabase>
#include <QSqlQueryModel>

namespace Ui {
class new_albums;
}

class new_albums : public QDialog
{
    Q_OBJECT

public:
    explicit new_albums(QWidget *parent = nullptr);
    ~new_albums();

private slots:
    void on_pushButton_2_clicked();

    void on_pushButton_clicked();

private:
    void openDatabase(const QString &dbPath);

    Ui::new_albums *ui;
    QSqlDatabase db;
};

#endif // NEW_ALBUMS_H
