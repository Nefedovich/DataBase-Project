#include "new_tracks_bd.h"
#include "ui_new_tracks_bd.h"

new_tracks_bd::new_tracks_bd(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::new_tracks_bd)
{
    ui->setupUi(this);
    openDatabase("/Users/test/Documents/Qt/DataBaseWidget/chinook.db");
}

new_tracks_bd::~new_tracks_bd()
{
    db.close();
    delete ui;
}

void new_tracks_bd::on_pushButton_2_clicked()
{
    hide();
    delete ui;
}

void new_tracks_bd::openDatabase(const QString &dbPath)
{
    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName(dbPath);

    if (!db.open()) {
        printf("Ошибка открытия базы данных");
    }
}

void new_tracks_bd::on_pushButton_clicked()
{
    QString Name = ui->lineEdit->text();
    QString AlbumId = ui->lineEdit_2->text();
    QString MediaTypeId = ui->lineEdit_3->text();
    QString GenreId = ui->lineEdit_4->text();
    QString Composer = ui->lineEdit_5->text();
    QString Milliseconds = ui->lineEdit_6->text();
    QString Bytes = ui->lineEdit_10->text();
    QString UnitPrice = ui->lineEdit_11->text();

    if (Name.isEmpty() || AlbumId.isEmpty() || MediaTypeId.isEmpty() || GenreId.isEmpty() || Composer.isEmpty() || Milliseconds.isEmpty() || Bytes.isEmpty() || UnitPrice.isEmpty()) {
        QMessageBox::warning(this, "Ошибка", "Пожалуйста, заполните все поля.");
        return;
    }
    bool isNumeric;
    int albId = AlbumId.toInt(&isNumeric);
    if (!isNumeric || albId <= 0) {
        QMessageBox::warning(this, "Ошибка", "ID должен быть числом больше нуля.");
        return;
    }
    QSqlQuery checkAlbumQuery(db);
    checkAlbumQuery.prepare("SELECT 1 FROM albums WHERE AlbumId = :Id");
    checkAlbumQuery.bindValue(":Id", albId);
    if (!checkAlbumQuery.exec() || !checkAlbumQuery.next()) {
        QMessageBox::warning(this, "Ошибка", "ID альбома не существует.");
        return;
    }

    int mtId = MediaTypeId.toInt(&isNumeric);
    if (!isNumeric || mtId <= 0) {
        QMessageBox::warning(this, "Ошибка", "ID типа должен быть числом больше нуля.");
        return;
    }
    QSqlQuery checkMTypeQuery(db);
    checkMTypeQuery.prepare("SELECT 1 FROM media_types WHERE MediaTypeId = :Id");
    checkMTypeQuery.bindValue(":Id", mtId);
    if (!checkMTypeQuery.exec() || !checkMTypeQuery.next()) {
        QMessageBox::warning(this, "Ошибка", "ID типа не существует.");
        return;
    }

    int gId =GenreId.toInt(&isNumeric);
    if (!isNumeric || gId <= 0) {
        QMessageBox::warning(this, "Ошибка", "ID жанра должен быть числом больше нуля.");
        return;
    }
    QSqlQuery checkGenreQuery(db);
    checkGenreQuery.prepare("SELECT 1 FROM genres WHERE GenreId = :Id");
    checkGenreQuery.bindValue(":Id", gId);
    if (!checkGenreQuery.exec() || !checkGenreQuery.next()) {
        QMessageBox::warning(this, "Ошибка", "ID жанра не существует.");
        return;
    }

    int m =Milliseconds.toInt(&isNumeric);
    if (!isNumeric || m <= 0) {
        QMessageBox::warning(this, "Ошибка", "Колличество миллисекунд должено быть числом больше нуля.");
        return;
    }
    int b =Bytes.toInt(&isNumeric);
    if (!isNumeric || b <= 0) {
        QMessageBox::warning(this, "Ошибка", "Колличество байт должено быть числом больше нуля.");
        return;
    }
    double uprice =UnitPrice.toDouble(&isNumeric);
    if (!isNumeric || uprice <= 0) {
        QMessageBox::warning(this, "Ошибка", "Цена должна быть числом больше нуля.");
        return;
    }

     QSqlQuery query(db);
     query.prepare("INSERT INTO tracks (Name, AlbumId, MediaTypeId, GenreId, Composer, Milliseconds, Bytes, UnitPrice) VALUES (:name, :albId, :mtId, :gId, :composer, :milli, :bytes, :price)");
     query.bindValue(":name", Name);
     query.bindValue(":albId", albId);
     query.bindValue(":mtId", mtId);
     query.bindValue(":gId", gId);
     query.bindValue(":composer", Composer);
     query.bindValue(":milli", m);
     query.bindValue(":bytes", b);
     query.bindValue(":price", uprice);


     if (!query.exec()) {
         qDebug() << "Ошибка при добавлении:" << query.lastError().text();
         QMessageBox::critical(this, "Ошибка", "Не удалось добавить строку в базу данных.");
     } else {
         qDebug() << "Строка успешно добавлена!";
         QMessageBox::information(this, "Успех", "Строка успешно добавлена!");
         close();
     }
}
