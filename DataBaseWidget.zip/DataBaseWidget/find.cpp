#include "Find.h"
#include "ui_find.h"
#include <QSqlQuery>
#include <QSqlQueryModel>

Find::Find(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Find)
{
    ui->setupUi(this);
    openDatabase("/Users/test/Documents/Qt/DataBaseWidget/chinook.db");

    ui->comboBox_searchType->addItem("Исполнитель");
    ui->comboBox_searchType->addItem("Альбом");
    connect(ui->comboBox_searchType, SIGNAL(currentIndexChanged(int)), this, SLOT(on_comboBox_searchType_currentIndexChanged(int)));
    connect(ui->pushButton_search, SIGNAL(clicked()), this, SLOT(on_pushButton_search_clicked()));
}

Find::~Find()
{
    db.close();
    delete ui;
}

void Find::openDatabase(const QString &dbPath)
{
    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName(dbPath);

    if (!db.open()) {
        printf("Ошибка открытия базы данных");
    }
}

void Find::on_comboBox_searchType_currentIndexChanged(int index)
{
    populateSearchValues();
}
