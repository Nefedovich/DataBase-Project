#include "new_artists.h"
#include "ui_new_artists.h"

new_artists::new_artists(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::new_artists)
{
    ui->setupUi(this);
    openDatabase("/Users/test/Documents/Qt/DataBaseWidget/chinook.db");
}

new_artists::~new_artists()
{
    db.close();
    delete ui;
}

void new_artists::on_pushButton_2_clicked()
{
    hide();
    delete ui;
}

void new_artists::openDatabase(const QString &dbPath)
{
    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName(dbPath);

    if (!db.open()) {
        printf("Ошибка открытия базы данных");
    }
}

void new_artists::on_pushButton_clicked()
{
    QString value1 = ui->lineEdit->text();

    if (value1.isEmpty()) {
        QMessageBox::warning(this, "Ошибка", "Пожалуйста, заполните все поля.");
        return;
    }

     QSqlQuery query(db);
     query.prepare("INSERT INTO artists (Name) VALUES (:name)");
     query.bindValue(":name", value1);

     if (!query.exec()) {
         qDebug() << "Ошибка при добавлении артиста:" << query.lastError().text();
         QMessageBox::critical(this, "Ошибка", "Не удалось добавить артиста в базу данных.");
     } else {
         qDebug() << "Артист успешно добавлен!";
         QMessageBox::information(this, "Успех", "Артист успешно добавлен!");
         close(); // Закрываем форму после успешного добавления
     }
}
