#ifndef NEW_PLAYLIST_H
#define NEW_PLAYLIST_H

#include <QDialog>
#include <QMessageBox>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
#include <QSqlDatabase>
#include <QSqlQueryModel>

namespace Ui {
class new_playlist;
}

class new_playlist : public QDialog
{
    Q_OBJECT

public:
    explicit new_playlist(QWidget *parent = nullptr);
    ~new_playlist();

private slots:
    void on_pushButton_2_clicked();
    void on_comboBox_searchType_currentIndexChanged(int index);
    void on_pushButton_search_clicked();
    void on_pushButton_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();

private:
    void openDatabase(const QString &dbPath);

    Ui::new_playlist *ui;
    QSqlDatabase db;
    void populateSearchValues();
    void search();
};

#endif // NEW_PLAYLIST_H
