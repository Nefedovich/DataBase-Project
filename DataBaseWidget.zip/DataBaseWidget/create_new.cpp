#include "create_new.h"
#include "ui_create_new.h"

create_new::create_new(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::create_new)
{
    ui->setupUi(this);
}

create_new::~create_new()
{
    delete ui;
}

void create_new::on_pushButton_clicked()
{
    em=new new_employee(this);
    em->show();
}

void create_new::on_pushButton_3_clicked()
{
    inv=new new_invoices_bd(this);
    inv->show();
}

void create_new::on_pushButton_5_clicked()
{
    inv_i=new new_invoice_items_bd(this);
    inv_i->show();
}


void create_new::on_pushButton_2_clicked()
{
    cst=new new_customer_bd(this);
    cst->show();
}

void create_new::on_pushButton_7_clicked()
{
    art=new new_artists(this);
    art->show();
}



void create_new::on_pushButton_4_clicked()
{
    alb=new new_albums(this);
    alb->show();
}



void create_new::on_pushButton_6_clicked()
{
    t=new new_tracks_bd(this);
    t->show();
}
