#include "new_customer_bd.h"
#include "ui_new_customer_bd.h"

new_customer_bd::new_customer_bd(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::new_customer_bd)
{
    ui->setupUi(this);
    openDatabase("/Users/test/Documents/Qt/DataBaseWidget/chinook.db");
}

new_customer_bd::~new_customer_bd()
{
    db.close();
    delete ui;
}

void new_customer_bd::on_pushButton_2_clicked()
{
    hide();
    delete ui;
}

void new_customer_bd::openDatabase(const QString &dbPath)
{
    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName(dbPath);

    if (!db.open()) {
        printf("Ошибка открытия базы данных");
    }
}

void new_customer_bd::on_pushButton_clicked()
{
    QString LastName = ui->lineEdit->text();
    QString FirstName = ui->lineEdit_2->text();
    QString Company = ui->lineEdit_3->text();
    QString Address = ui->lineEdit_4->text();
    QString City = ui->lineEdit_5->text();
    QString State = ui->lineEdit_6->text();
    QString Country = ui->lineEdit_10->text();
    QString PostalCode = ui->lineEdit_11->text();
    QString Phone = ui->lineEdit_9->text();
    QString Fax = ui->lineEdit_7->text();
    QString Email = ui->lineEdit_12->text();
    QString SupportRepId = ui->lineEdit_8->text();

    if (LastName.isEmpty() || FirstName.isEmpty() || Company.isEmpty() || Address.isEmpty() || City.isEmpty() || State.isEmpty() || Country.isEmpty() || PostalCode.isEmpty() || Phone.isEmpty() || Fax.isEmpty() || Email.isEmpty() || SupportRepId.isEmpty()) {
        QMessageBox::warning(this, "Ошибка", "Пожалуйста, заполните все поля.");
        return;
    }

    bool isNumeric;
    int artistId = SupportRepId.toInt(&isNumeric);
    if (!isNumeric || artistId <= 0) {
        QMessageBox::warning(this, "Ошибка", "ID сотрудника должен быть числом больше нуля.");
        return;
    }

    QSqlQuery checkEmployeeQuery(db);
    checkEmployeeQuery.prepare("SELECT 1 FROM employees WHERE EmployeeId = :Id");
    checkEmployeeQuery.bindValue(":Id", artistId);
    if (!checkEmployeeQuery.exec() || !checkEmployeeQuery.next()) {
        QMessageBox::warning(this, "Ошибка", "ID сотрудника не существует.");
        return;
    }

     QSqlQuery query(db);
     query.prepare("INSERT INTO customers (LastName, FirstName, Company, Address, City, State, Country, PostalCode, Phone, Fax, Email, SupportRepId) VALUES (:lastname, :firstname, :company, :address, :city, :state, :country, :postalcode, :phone, :fax, :email, ;support)");
     query.bindValue(":lastname", LastName);
     query.bindValue(":firstname",FirstName);
     query.bindValue(":company", Company);
     query.bindValue(":address", Address);
     query.bindValue(":city", City);
     query.bindValue(":state", State);
     query.bindValue(":country", Country);
     query.bindValue(":postalcode", PostalCode);
     query.bindValue(":phone", Phone);
     query.bindValue(":fax", Fax);
     query.bindValue(":email", Email);
     query.bindValue(":support", SupportRepId);

     if (!query.exec()) {
         qDebug() << "Ошибка при добавлении сотрудника:" << query.lastError().text();
         QMessageBox::critical(this, "Ошибка", "Не удалось добавить сотрудника в базу данных.");
     } else {
         qDebug() << "Сотрудник успешно добавлен!";
         QMessageBox::information(this, "Успех", "Сотрудник успешно добавлен!");
         close();
     }
}
