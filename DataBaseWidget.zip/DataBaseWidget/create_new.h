#ifndef CREATE_NEW_H
#define CREATE_NEW_H

#include <QDialog>
#include "new_employee.h"
#include "new_customer_bd.h"
#include "new_invoice_items_bd.h"
#include "new_invoices_bd.h"
#include "new_albums.h"
#include "new_artists.h"
#include "new_tracks_bd.h"

namespace Ui {
class create_new;
}

class create_new : public QDialog
{
    Q_OBJECT

public:
    explicit create_new(QWidget *parent = nullptr);
    ~create_new();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_5_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_7_clicked();

    void on_pushButton_4_clicked();

    void on_pushButton_6_clicked();

private:
    Ui::create_new *ui;
    new_employee *em;
    new_customer_bd *cst;
    new_invoices_bd *inv;
    new_invoice_items_bd *inv_i;
    new_albums *alb;
    new_artists *art;
    new_tracks_bd *t;
};

#endif // CREATE_NEW_H
