#include "new_invoice_items_bd.h"
#include "ui_new_invoice_items_bd.h"

new_invoice_items_bd::new_invoice_items_bd(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::new_invoice_items_bd)
{
    ui->setupUi(this);
    openDatabase("/Users/test/Documents/Qt/DataBaseWidget/chinook.db");
}

new_invoice_items_bd::~new_invoice_items_bd()
{
    db.close();
    delete ui;
}

void new_invoice_items_bd::on_pushButton_2_clicked()
{
    hide();
    delete ui;
}

void new_invoice_items_bd::openDatabase(const QString &dbPath)
{
    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName(dbPath);

    if (!db.open()) {
        printf("Ошибка открытия базы данных");
    }
}

void new_invoice_items_bd::on_pushButton_clicked()
{
    QString InvoiceId = ui->lineEdit->text();
    QString TrackId = ui->lineEdit_2->text();
    QString Quantity = ui->lineEdit_4->text();

    if (InvoiceId.isEmpty() || TrackId.isEmpty() || Quantity.isEmpty()) {
        QMessageBox::warning(this, "Ошибка", "Пожалуйста, заполните все поля.");
        return;
    }
    bool isNumeric;
    int invId = InvoiceId.toInt(&isNumeric);
    if (!isNumeric || invId <= 0) {
        QMessageBox::warning(this, "Ошибка", "ID должен быть числом больше нуля.");
        return;
    }

    int tId = TrackId.toInt(&isNumeric);
    if (!isNumeric || tId <= 0) {
        QMessageBox::warning(this, "Ошибка", "ID трека должен быть числом больше нуля.");
        return;
    }

    int Quant=Quantity.toInt(&isNumeric);
    if (!isNumeric || Quant <= 0) {
        QMessageBox::warning(this, "Ошибка", "Количество должено быть числом больше нуля.");
        return;
    }

     QSqlQuery checkInvoiceQuery(db);
     checkInvoiceQuery.prepare("SELECT 1 FROM invoices WHERE InvoiceId = :invoiceId");
     checkInvoiceQuery.bindValue(":invoiceId", invId);
     if (!checkInvoiceQuery.exec() || !checkInvoiceQuery.next()) {
         QMessageBox::warning(this, "Ошибка", "ID счета не существует.");
         return;
     }

     QSqlQuery checkTrackQuery(db);
     checkTrackQuery.prepare("SELECT 1 FROM tracks WHERE TrackId = :trackId");
     checkTrackQuery.bindValue(":trackId", tId);
     if (!checkTrackQuery.exec() || !checkTrackQuery.next()) {
         QMessageBox::warning(this, "Ошибка", "ID трека не существует.");
         return;
     }

     QSqlQuery priceQuery(db);
         priceQuery.prepare("SELECT UnitPrice FROM tracks WHERE TrackId = :trackId");
         priceQuery.bindValue(":trackId", tId);

         if (!priceQuery.exec() || !priceQuery.next()) {
             QMessageBox::warning(this, "Ошибка", "Не удалось найти цену по ID трека.");
             return;
         }

     double Price = priceQuery.value(0).toDouble();

     QSqlQuery query(db);
     query.prepare("INSERT INTO invoice_items (InvoiceId, TrackId, UnitPrice, Quantity) VALUES (:invoiceId, :trackId, :price, :quantity)");
     query.bindValue(":invoiceId", invId);
     query.bindValue(":trackId", tId);
     query.bindValue(":price", Price);
     query.bindValue(":quantity", Quant);

     if (!query.exec()) {
         qDebug() << "Ошибка при добавлении:" << query.lastError().text();
         QMessageBox::critical(this, "Ошибка", "Не удалось добавить строку в базу данных.");
     } else {
         qDebug() << "Строка успешно добавлена!";
         QMessageBox::information(this, "Успех", "Строка успешно добавлена!");
         close();
     }
}
