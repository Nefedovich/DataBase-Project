#include "new_employee.h"
#include "ui_new_employee.h"

new_employee::new_employee(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::new_employee)
{
    ui->setupUi(this);
    openDatabase("/Users/test/Documents/Qt/DataBaseWidget/chinook.db");
}

new_employee::~new_employee()
{
    db.close();
    delete ui;
}

void new_employee::on_pushButton_2_clicked()
{
    hide();
    delete ui;
}

void new_employee::openDatabase(const QString &dbPath)
{
    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName(dbPath);

    if (!db.open()) {
        printf("Ошибка открытия базы данных");
    }
}

void new_employee::on_pushButton_clicked()
{
    QString LastName = ui->lineEdit->text();
    QString FirstName = ui->lineEdit_2->text();
    QString Title = ui->lineEdit_3->text();
    QString BirthDate = ui->lineEdit_4->text();
    QString HireDate = ui->lineEdit_5->text();
    QString Address = ui->lineEdit_6->text();
    QString Reports = ui->lineEdit_7->text();
    QString City = ui->lineEdit_14->text();
    QString State = ui->lineEdit_8->text();
    QString Country = ui->lineEdit_10->text();
    QString PostalCode = ui->lineEdit_11->text();
    QString Phone = ui->lineEdit_13->text();
    QString Fax = ui->lineEdit_9->text();
    QString Email = ui->lineEdit_12->text();

    if (LastName.isEmpty() || FirstName.isEmpty() || Title.isEmpty() || BirthDate.isEmpty() || HireDate.isEmpty() || Address.isEmpty() ||
            Reports.isEmpty() || City.isEmpty() || State.isEmpty() || Country.isEmpty() || PostalCode.isEmpty() || Phone.isEmpty() || Fax.isEmpty() || Email.isEmpty()) {
        QMessageBox::warning(this, "Ошибка", "Пожалуйста, заполните все поля.");
        return;
    }

     QSqlQuery query(db);
     query.prepare("INSERT INTO employees (LastName, FirstName, Title, ReportsTo, BirthDate, HireDate, Address, City, State, Country, PostalCode, Phone, Fax, Email) VALUES (:lastname, :firstname, :title, :reports, :birth, :hire, :address, :city, :state, :country, :postalcode, :phone, :fax, :email)");
     query.bindValue(":lastname", LastName);
     query.bindValue(":firstname",FirstName);
     query.bindValue(":title", Title);
     query.bindValue(":reports", Reports);
     query.bindValue(":birth", BirthDate);
     query.bindValue(":hire", HireDate);
     query.bindValue(":address", Address);
     query.bindValue(":city", City);
     query.bindValue(":state", State);
     query.bindValue(":country", Country);
     query.bindValue(":postalcode", PostalCode);
     query.bindValue(":phone", Phone);
     query.bindValue(":fax", Fax);
     query.bindValue(":email", Email);

     if (!query.exec()) {
         qDebug() << "Ошибка при добавлении сотрудника:" << query.lastError().text();
         QMessageBox::critical(this, "Ошибка", "Не удалось добавить сотрудника в базу данных.");
     } else {
         qDebug() << "Сотрудник успешно добавлен!";
         QMessageBox::information(this, "Успех", "Сотрудник успешно добавлен!");
         close();
     }
}
