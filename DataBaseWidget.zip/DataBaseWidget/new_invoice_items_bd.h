#ifndef NEW_INVOICE_ITEMS_BD_H
#define NEW_INVOICE_ITEMS_BD_H

#include <QDialog>
#include <QMessageBox>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
#include <QSqlDatabase>
#include <QSqlQueryModel>

namespace Ui {
class new_invoice_items_bd;
}

class new_invoice_items_bd : public QDialog
{
    Q_OBJECT

public:
    explicit new_invoice_items_bd(QWidget *parent = nullptr);
    ~new_invoice_items_bd();

private slots:
    void on_pushButton_2_clicked();

    void on_pushButton_clicked();

private:
    void openDatabase(const QString &dbPath);
    Ui::new_invoice_items_bd *ui;
    QSqlDatabase db;
};

#endif // NEW_INVOICE_ITEMS_BD_H
