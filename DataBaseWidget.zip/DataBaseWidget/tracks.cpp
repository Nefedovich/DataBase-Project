#include "tracks.h"
#include "ui_tracks.h"

tracks::tracks(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::tracks)
{
    ui->setupUi(this);
}

tracks::~tracks()
{
    delete ui;
}
