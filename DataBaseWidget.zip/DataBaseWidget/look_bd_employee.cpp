#include "look_bd_employee.h"
#include "ui_look_bd_employee.h"
#include <QSqlQuery>
#include <QSqlQueryModel>

look_bd_employee::look_bd_employee(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::look_bd_employee)
{
    ui->setupUi(this);
    connect(ui->tableSelector, &QComboBox::currentTextChanged, this, &look_bd_client::onTableChanged);
    openDatabase(pat_db);
    loadTable(ui->tableSelector->currentText());
}

look_bd_client::~look_bd_client()
{
    db.close();
    delete ui;
}

void look_bd_client::openDatabase(const QString &dbPath)
{
    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName(dbPath);

    if (!db.open()) {
        printf("Ошибка открытия базы данных");
    }
}

void look_bd_client::loadTable(const QString &tableName)
{
    QSqlQueryModel *model = new QSqlQueryModel(this);
    QSqlQuery query(db);

    query.prepare(QString("SELECT * FROM %1").arg(tableName));

    if (!query.exec()) {
        printf("Ошибка выполнения запроса");
        return;
    }

    model->setQuery(query);
    ui->tableView->setModel(model);
}


void look_bd_client::onTableChanged(const QString &tableName)
{
    loadTable(tableName);
}
