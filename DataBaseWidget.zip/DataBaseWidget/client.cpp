#include "client.h"
#include "ui_client.h"

client::client(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::client)
{
    ui->setupUi(this);
}

client::~client()
{
    delete ui;
}

void client::on_pushButton_clicked()
{
    window=new look_bd_client(this);
    window->show();
}

void client::on_pushButton_2_clicked()
{
    f=new find_bd(this);
    f->show();
}

void client::on_pushButton_3_clicked()
{
    np=new new_playlist(this);
    np->show();
}

void client::on_pushButton_4_clicked()
{
    st=new statistics(this);
    st->show();
}

