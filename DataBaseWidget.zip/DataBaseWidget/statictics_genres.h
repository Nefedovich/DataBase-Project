#ifndef STATICTICS_GENRES_H
#define STATICTICS_GENRES_H

#include <QDialog>
#include <QMessageBox>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
#include <QSqlDatabase>

namespace Ui {
class statictics_genres;
}

class statictics_genres : public QDialog
{
    Q_OBJECT

public:
    explicit statictics_genres(QWidget *parent = nullptr);
    ~statictics_genres();
    void openDatabase(const QString &dbPath);

private:
    QSqlDatabase db;
    Ui::statictics_genres *ui;
};

#endif // STATICTICS_GENRES_H
