#ifndef NEW_CUSTOMER_BD_H
#define NEW_CUSTOMER_BD_H

#include <QDialog>
#include <QMessageBox>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
#include <QSqlDatabase>
#include <QSqlQueryModel>

namespace Ui {
class new_customer_bd;
}

class new_customer_bd : public QDialog
{
    Q_OBJECT

public:
    explicit new_customer_bd(QWidget *parent = nullptr);
    ~new_customer_bd();

private slots:
    void on_pushButton_2_clicked();

    void on_pushButton_clicked();

private:
    void openDatabase(const QString &dbPath);

    Ui::new_customer_bd *ui;
    QSqlDatabase db;
};

#endif // NEW_CUSTOMER_BD_H
