#include "stat_employee.h"
#include "ui_stat_employee.h"

stat_employee::stat_employee(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::stat_employee)
{
    ui->setupUi(this);
}

stat_employee::~stat_employee()
{
    delete ui;
}
