#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include <QDialog>
#include "look_bd.h"
#include "create_new.h"
#include "find_emp.h"
#include "stat_employee.h"

namespace Ui {
class employee;
}

class employee : public QDialog
{
    Q_OBJECT

public:
    explicit employee(QWidget *parent = nullptr);
    ~employee();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();

private:
    Ui::employee *ui;
    look_bd *window;
    create_new *window2;
    find_emp *window3;
    stat_employee *window4;
};

#endif // EMPLOYEE_H
