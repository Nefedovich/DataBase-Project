#ifndef LOOK_BD_EMPLOYEE_H
#define LOOK_BD_EMPLOYEE_H

#include <QDialog>
#include <QSqlDatabase>
#include <QSqlQueryModel>

namespace Ui {
class look_bd_employee;
}

class look_bd_employee : public QDialog
{
    Q_OBJECT

public:
    explicit look_bd_employee(QWidget *parent = nullptr);
    ~look_bd_employee();

private:
    void openDatabase(const QString &dbPath);
    void loadTable(const QString &tableName);

    Ui::look_bd_employee *ui;
    QSqlDatabase db;

private slots:
    void onTableChanged(const QString &tableName);
};

#endif // LOOK_BD_EMPLOYEE_H
