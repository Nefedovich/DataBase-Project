#ifndef STATISTICS_CITIES_H
#define STATISTICS_CITIES_H

#include <QDialog>
#include <QMessageBox>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
#include <QSqlDatabase>
#include <QSqlQueryModel>

namespace Ui {
class statistics_cities;
}

class statistics_cities : public QDialog
{
    Q_OBJECT

public:
    explicit statistics_cities(QWidget *parent = nullptr);
    ~statistics_cities();
    void openDatabase(const QString &dbPath);

private:
    QSqlDatabase db;
    Ui::statistics_cities *ui;
};

#endif // STATISTICS_CITIES_H
