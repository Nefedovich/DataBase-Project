#include "statistics_love_genres.h"
#include "ui_statistics_love_genres.h"

statistics_love_genres::statistics_love_genres(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::statistics_love_genres)
{
    ui->setupUi(this);
}

statistics_love_genres::~statistics_love_genres()
{
    delete ui;
}
