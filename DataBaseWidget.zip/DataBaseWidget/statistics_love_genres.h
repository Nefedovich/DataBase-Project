#ifndef STATISTICS_LOVE_GENRES_H
#define STATISTICS_LOVE_GENRES_H

#include <QDialog>

namespace Ui {
class statistics_love_genres;
}

class statistics_love_genres : public QDialog
{
    Q_OBJECT

public:
    explicit statistics_love_genres(QWidget *parent = nullptr);
    ~statistics_love_genres();

private:
    Ui::statistics_love_genres *ui;
};

#endif // STATISTICS_LOVE_GENRES_H
