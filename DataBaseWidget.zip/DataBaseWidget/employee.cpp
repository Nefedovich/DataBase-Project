#include "employee.h"
#include "ui_employee.h"

employee::employee(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::employee)
{
    ui->setupUi(this);
}

employee::~employee()
{
    delete ui;
}

void employee::on_pushButton_clicked()
{
    window=new look_bd(this);
    window->show();
}

void employee::on_pushButton_2_clicked()
{
    window2=new create_new(this);
    window2->show();
}

void employee::on_pushButton_3_clicked()
{
    window3=new find_emp(this);
    window3->show();
}

void employee::on_pushButton_4_clicked()
{
    window4=new stat_employee(this);
    window4->show();
}

