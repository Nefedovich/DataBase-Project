/********************************************************************************
** Form generated from reading UI file 'new_playlist.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_NEW_PLAYLIST_H
#define UI_NEW_PLAYLIST_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableView>

QT_BEGIN_NAMESPACE

class Ui_new_playlist
{
public:
    QLabel *label;
    QPushButton *pushButton_2;
    QPushButton *pushButton;
    QLineEdit *lineEdit;
    QLineEdit *lineEdit_2;
    QPushButton *pushButton_3;
    QLabel *label_2;
    QPushButton *pushButton_4;
    QComboBox *comboBox_searchType;
    QComboBox *comboBox_searchValue;
    QTableView *tableView_results;
    QPushButton *pushButton_search;

    void setupUi(QDialog *new_playlist)
    {
        if (new_playlist->objectName().isEmpty())
            new_playlist->setObjectName(QString::fromUtf8("new_playlist"));
        new_playlist->resize(809, 606);
        QPalette palette;
        QBrush brush(QColor(255, 255, 255, 255));
        brush.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Base, brush);
        QBrush brush1(QColor(250, 164, 154, 255));
        brush1.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Window, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Base, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Window, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Base, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Window, brush1);
        new_playlist->setPalette(palette);
        new_playlist->setStyleSheet(QString::fromUtf8("QPushButton{background-color: rgb(250, 222, 210); border-radius: 9px;}\n"
"QPushButton{font: 63 7.5pt \"Sitka Small Semibold\"; color:  rgb(184, 53, 86);}\n"
"QPushButton:pressed{background-color: rgb(220, 209, 179)}\n"
"\n"
"QLineEdit{background-color: rgb(250, 244, 241); border-radius: 9px; font: 63 7.5pt \"Sitka Small Semibold\"; color:  rgb(184, 53, 86);}\n"
"\n"
"QComboBox{background-color: rgb(250, 244, 241); border-radius: 9px; font: 63 7.5pt \"Sitka Small Semibold\"; color:  rgb(184, 53, 86);}\n"
"\n"
"QLabel{font: 63 7.5pt \"Sitka Small Semibold\"; color:  rgb(184, 53, 86);}"));
        label = new QLabel(new_playlist);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(30, 40, 141, 21));
        pushButton_2 = new QPushButton(new_playlist);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(170, 550, 131, 41));
        pushButton = new QPushButton(new_playlist);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(500, 30, 161, 41));
        lineEdit = new QLineEdit(new_playlist);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(110, 40, 361, 20));
        lineEdit_2 = new QLineEdit(new_playlist);
        lineEdit_2->setObjectName(QString::fromUtf8("lineEdit_2"));
        lineEdit_2->setGeometry(QRect(110, 480, 361, 20));
        pushButton_3 = new QPushButton(new_playlist);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setGeometry(QRect(500, 470, 131, 41));
        label_2 = new QLabel(new_playlist);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(30, 480, 141, 21));
        pushButton_4 = new QPushButton(new_playlist);
        pushButton_4->setObjectName(QString::fromUtf8("pushButton_4"));
        pushButton_4->setGeometry(QRect(30, 550, 131, 41));
        comboBox_searchType = new QComboBox(new_playlist);
        comboBox_searchType->setObjectName(QString::fromUtf8("comboBox_searchType"));
        comboBox_searchType->setGeometry(QRect(30, 110, 241, 22));
        comboBox_searchType->setStyleSheet(QString::fromUtf8("QComboBox{background-color: rgb(250, 244, 241); border-radius: 9px; font: 63 7.5pt \"Sitka Small Semibold\"; color:  rgb(184, 53, 86);}"));
        comboBox_searchValue = new QComboBox(new_playlist);
        comboBox_searchValue->setObjectName(QString::fromUtf8("comboBox_searchValue"));
        comboBox_searchValue->setGeometry(QRect(30, 140, 241, 22));
        tableView_results = new QTableView(new_playlist);
        tableView_results->setObjectName(QString::fromUtf8("tableView_results"));
        tableView_results->setGeometry(QRect(30, 190, 721, 271));
        pushButton_search = new QPushButton(new_playlist);
        pushButton_search->setObjectName(QString::fromUtf8("pushButton_search"));
        pushButton_search->setGeometry(QRect(290, 120, 75, 23));

        retranslateUi(new_playlist);

        QMetaObject::connectSlotsByName(new_playlist);
    } // setupUi

    void retranslateUi(QDialog *new_playlist)
    {
        new_playlist->setWindowTitle(QApplication::translate("new_playlist", "Dialog", nullptr));
        label->setText(QApplication::translate("new_playlist", "Name", nullptr));
        pushButton_2->setText(QApplication::translate("new_playlist", "\320\236\321\202\320\274\320\265\320\275\320\260", nullptr));
        pushButton->setText(QApplication::translate("new_playlist", "\320\224\320\276\320\261\320\260\320\262\320\270\321\202\321\214 \320\277\320\273\320\265\320\271\320\273\320\270\321\201\321\202", nullptr));
        pushButton_3->setText(QApplication::translate("new_playlist", "\320\224\320\276\320\261\320\260\320\262\320\270\321\202\321\214 \321\202\321\200\320\265\320\272", nullptr));
        label_2->setText(QApplication::translate("new_playlist", "TrackId", nullptr));
        pushButton_4->setText(QApplication::translate("new_playlist", "\320\223\320\276\321\202\320\276\320\262\320\276", nullptr));
        pushButton_search->setText(QApplication::translate("new_playlist", "\320\235\320\260\320\271\321\202\320\270", nullptr));
    } // retranslateUi

};

namespace Ui {
    class new_playlist: public Ui_new_playlist {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_NEW_PLAYLIST_H
