/********************************************************************************
** Form generated from reading UI file 'new_invoice_items_bd.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_NEW_INVOICE_ITEMS_BD_H
#define UI_NEW_INVOICE_ITEMS_BD_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_new_invoice_items_bd
{
public:
    QLineEdit *lineEdit_4;
    QLabel *label_4;
    QLineEdit *lineEdit_2;
    QLineEdit *lineEdit;
    QLabel *label_2;
    QLabel *label;
    QPushButton *pushButton_2;
    QPushButton *pushButton;

    void setupUi(QDialog *new_invoice_items_bd)
    {
        if (new_invoice_items_bd->objectName().isEmpty())
            new_invoice_items_bd->setObjectName(QString::fromUtf8("new_invoice_items_bd"));
        new_invoice_items_bd->resize(578, 216);
        QPalette palette;
        QBrush brush(QColor(255, 255, 255, 255));
        brush.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Base, brush);
        QBrush brush1(QColor(250, 164, 154, 255));
        brush1.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Window, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Base, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Window, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Base, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Window, brush1);
        new_invoice_items_bd->setPalette(palette);
        new_invoice_items_bd->setStyleSheet(QString::fromUtf8("QPushButton{background-color: rgb(250, 222, 210); border-radius: 9px;}\n"
"QPushButton{font: 63 7.5pt \"Sitka Small Semibold\"; color:  rgb(184, 53, 86);}\n"
"QPushButton:pressed{background-color: rgb(220, 209, 179)}\n"
"\n"
"QLineEdit{background-color: rgb(250, 244, 241); border-radius: 9px; font: 63 7.5pt \"Sitka Small Semibold\"; color:  rgb(184, 53, 86);}\n"
"\n"
"QLabel{font: 63 7.5pt \"Sitka Small Semibold\"; color:  rgb(184, 53, 86);}"));
        lineEdit_4 = new QLineEdit(new_invoice_items_bd);
        lineEdit_4->setObjectName(QString::fromUtf8("lineEdit_4"));
        lineEdit_4->setGeometry(QRect(180, 100, 361, 20));
        label_4 = new QLabel(new_invoice_items_bd);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(30, 100, 141, 21));
        lineEdit_2 = new QLineEdit(new_invoice_items_bd);
        lineEdit_2->setObjectName(QString::fromUtf8("lineEdit_2"));
        lineEdit_2->setGeometry(QRect(180, 70, 361, 20));
        lineEdit = new QLineEdit(new_invoice_items_bd);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(180, 40, 361, 20));
        label_2 = new QLabel(new_invoice_items_bd);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(30, 70, 141, 21));
        label = new QLabel(new_invoice_items_bd);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(30, 40, 141, 21));
        pushButton_2 = new QPushButton(new_invoice_items_bd);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(270, 150, 131, 41));
        pushButton = new QPushButton(new_invoice_items_bd);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(120, 150, 131, 41));

        retranslateUi(new_invoice_items_bd);

        QMetaObject::connectSlotsByName(new_invoice_items_bd);
    } // setupUi

    void retranslateUi(QDialog *new_invoice_items_bd)
    {
        new_invoice_items_bd->setWindowTitle(QApplication::translate("new_invoice_items_bd", "Dialog", nullptr));
        label_4->setText(QApplication::translate("new_invoice_items_bd", "Quantity", nullptr));
        label_2->setText(QApplication::translate("new_invoice_items_bd", "TrackId", nullptr));
        label->setText(QApplication::translate("new_invoice_items_bd", "InvoiceId", nullptr));
        pushButton_2->setText(QApplication::translate("new_invoice_items_bd", "\320\236\321\202\320\274\320\265\320\275\320\260", nullptr));
        pushButton->setText(QApplication::translate("new_invoice_items_bd", "\320\224\320\276\320\261\320\260\320\262\320\270\321\202\321\214 \320\267\320\260\320\277\320\270\321\201\321\214", nullptr));
    } // retranslateUi

};

namespace Ui {
    class new_invoice_items_bd: public Ui_new_invoice_items_bd {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_NEW_INVOICE_ITEMS_BD_H
