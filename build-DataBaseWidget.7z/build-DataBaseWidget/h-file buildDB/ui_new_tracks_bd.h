/********************************************************************************
** Form generated from reading UI file 'new_tracks_bd.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_NEW_TRACKS_BD_H
#define UI_NEW_TRACKS_BD_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_new_tracks_bd
{
public:
    QLineEdit *lineEdit_3;
    QLabel *label;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *label_10;
    QPushButton *pushButton_2;
    QLineEdit *lineEdit_5;
    QLabel *label_2;
    QLabel *label_6;
    QLineEdit *lineEdit;
    QLineEdit *lineEdit_10;
    QPushButton *pushButton;
    QLabel *label_11;
    QLineEdit *lineEdit_11;
    QLineEdit *lineEdit_6;
    QLineEdit *lineEdit_2;
    QLineEdit *lineEdit_4;
    QLabel *label_3;

    void setupUi(QDialog *new_tracks_bd)
    {
        if (new_tracks_bd->objectName().isEmpty())
            new_tracks_bd->setObjectName(QString::fromUtf8("new_tracks_bd"));
        new_tracks_bd->resize(582, 352);
        QPalette palette;
        QBrush brush(QColor(255, 255, 255, 255));
        brush.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Base, brush);
        QBrush brush1(QColor(250, 164, 154, 255));
        brush1.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Window, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Base, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Window, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Base, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Window, brush1);
        new_tracks_bd->setPalette(palette);
        new_tracks_bd->setStyleSheet(QString::fromUtf8("QPushButton{background-color: rgb(250, 222, 210); border-radius: 9px;}\n"
"QPushButton{font: 63 7.5pt \"Sitka Small Semibold\"; color:  rgb(184, 53, 86);}\n"
"QPushButton:pressed{background-color: rgb(220, 209, 179)}\n"
"\n"
"QLineEdit{background-color: rgb(250, 244, 241); border-radius: 9px; font: 63 7.5pt \"Sitka Small Semibold\"; color:  rgb(184, 53, 86);}\n"
"\n"
"QLabel{font: 63 7.5pt \"Sitka Small Semibold\"; color:  rgb(184, 53, 86);}"));
        lineEdit_3 = new QLineEdit(new_tracks_bd);
        lineEdit_3->setObjectName(QString::fromUtf8("lineEdit_3"));
        lineEdit_3->setGeometry(QRect(180, 80, 361, 20));
        label = new QLabel(new_tracks_bd);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(30, 20, 141, 21));
        label_4 = new QLabel(new_tracks_bd);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(30, 110, 141, 21));
        label_5 = new QLabel(new_tracks_bd);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(30, 140, 141, 21));
        label_10 = new QLabel(new_tracks_bd);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setGeometry(QRect(30, 200, 141, 21));
        pushButton_2 = new QPushButton(new_tracks_bd);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(270, 270, 131, 41));
        lineEdit_5 = new QLineEdit(new_tracks_bd);
        lineEdit_5->setObjectName(QString::fromUtf8("lineEdit_5"));
        lineEdit_5->setGeometry(QRect(180, 140, 361, 20));
        label_2 = new QLabel(new_tracks_bd);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(30, 50, 141, 21));
        label_6 = new QLabel(new_tracks_bd);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(30, 170, 141, 21));
        lineEdit = new QLineEdit(new_tracks_bd);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(180, 20, 361, 20));
        lineEdit_10 = new QLineEdit(new_tracks_bd);
        lineEdit_10->setObjectName(QString::fromUtf8("lineEdit_10"));
        lineEdit_10->setGeometry(QRect(180, 200, 361, 20));
        pushButton = new QPushButton(new_tracks_bd);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(120, 270, 131, 41));
        label_11 = new QLabel(new_tracks_bd);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        label_11->setGeometry(QRect(30, 230, 141, 21));
        lineEdit_11 = new QLineEdit(new_tracks_bd);
        lineEdit_11->setObjectName(QString::fromUtf8("lineEdit_11"));
        lineEdit_11->setGeometry(QRect(180, 230, 361, 20));
        lineEdit_6 = new QLineEdit(new_tracks_bd);
        lineEdit_6->setObjectName(QString::fromUtf8("lineEdit_6"));
        lineEdit_6->setGeometry(QRect(180, 170, 361, 20));
        lineEdit_2 = new QLineEdit(new_tracks_bd);
        lineEdit_2->setObjectName(QString::fromUtf8("lineEdit_2"));
        lineEdit_2->setGeometry(QRect(180, 50, 361, 20));
        lineEdit_4 = new QLineEdit(new_tracks_bd);
        lineEdit_4->setObjectName(QString::fromUtf8("lineEdit_4"));
        lineEdit_4->setGeometry(QRect(180, 110, 361, 20));
        label_3 = new QLabel(new_tracks_bd);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(30, 80, 141, 21));

        retranslateUi(new_tracks_bd);

        QMetaObject::connectSlotsByName(new_tracks_bd);
    } // setupUi

    void retranslateUi(QDialog *new_tracks_bd)
    {
        new_tracks_bd->setWindowTitle(QApplication::translate("new_tracks_bd", "Dialog", nullptr));
        label->setText(QApplication::translate("new_tracks_bd", "Name", nullptr));
        label_4->setText(QApplication::translate("new_tracks_bd", "GenreId", nullptr));
        label_5->setText(QApplication::translate("new_tracks_bd", "Composer", nullptr));
        label_10->setText(QApplication::translate("new_tracks_bd", "Bytes", nullptr));
        pushButton_2->setText(QApplication::translate("new_tracks_bd", "\320\236\321\202\320\274\320\265\320\275\320\260", nullptr));
        label_2->setText(QApplication::translate("new_tracks_bd", "AlbumId", nullptr));
        label_6->setText(QApplication::translate("new_tracks_bd", "Milliseconds", nullptr));
        pushButton->setText(QApplication::translate("new_tracks_bd", "\320\224\320\276\320\261\320\260\320\262\320\270\321\202\321\214 \320\267\320\260\320\277\320\270\321\201\321\214", nullptr));
        label_11->setText(QApplication::translate("new_tracks_bd", "UnitPrice", nullptr));
        label_3->setText(QApplication::translate("new_tracks_bd", "MediaTypeId", nullptr));
    } // retranslateUi

};

namespace Ui {
    class new_tracks_bd: public Ui_new_tracks_bd {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_NEW_TRACKS_BD_H
