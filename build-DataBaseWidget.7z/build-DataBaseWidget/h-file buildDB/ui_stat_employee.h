/********************************************************************************
** Form generated from reading UI file 'stat_employee.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_STAT_EMPLOYEE_H
#define UI_STAT_EMPLOYEE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_stat_employee
{
public:
    QPushButton *pushButton;

    void setupUi(QDialog *stat_employee)
    {
        if (stat_employee->objectName().isEmpty())
            stat_employee->setObjectName(QString::fromUtf8("stat_employee"));
        stat_employee->resize(443, 229);
        QPalette palette;
        QBrush brush(QColor(255, 255, 255, 255));
        brush.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Base, brush);
        QBrush brush1(QColor(250, 164, 154, 255));
        brush1.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Window, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Base, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Window, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Base, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Window, brush1);
        stat_employee->setPalette(palette);
        stat_employee->setStyleSheet(QString::fromUtf8("QPushButton{background-color: rgb(250, 222, 210); border-radius: 9px;}\n"
"QPushButton{font: 63 7.5pt \"Sitka Small Semibold\"; color:  rgb(184, 53, 86);}\n"
"QPushButton:pressed{background-color: rgb(220, 209, 179)}\n"
"\n"
"QLineEdit{background-color: rgb(250, 244, 241); border-radius: 9px; font: 63 7.5pt \"Sitka Small Semibold\"; color:  rgb(184, 53, 86);}\n"
"\n"
"QLabel{font: 63 7.5pt \"Sitka Small Semibold\"; color:  rgb(184, 53, 86);}"));
        pushButton = new QPushButton(stat_employee);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(50, 90, 331, 51));

        retranslateUi(stat_employee);

        QMetaObject::connectSlotsByName(stat_employee);
    } // setupUi

    void retranslateUi(QDialog *stat_employee)
    {
        stat_employee->setWindowTitle(QApplication::translate("stat_employee", "Dialog", nullptr));
        pushButton->setText(QApplication::translate("stat_employee", "\320\240\320\260\321\201\320\277\321\200\320\265\320\264\320\265\320\273\320\265\320\275\320\270\320\265 \321\201\320\276\321\202\321\200\321\203\320\264\320\275\320\270\320\272\320\276\320\262 \320\277\320\276 \320\277\321\200\320\276\320\264\320\260\320\266\320\260\320\274", nullptr));
    } // retranslateUi

};

namespace Ui {
    class stat_employee: public Ui_stat_employee {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_STAT_EMPLOYEE_H
