/********************************************************************************
** Form generated from reading UI file 'new_albums.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_NEW_ALBUMS_H
#define UI_NEW_ALBUMS_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_new_albums
{
public:
    QLineEdit *lineEdit_2;
    QLabel *label;
    QLineEdit *lineEdit;
    QLabel *label_2;
    QPushButton *pushButton_2;
    QPushButton *pushButton;

    void setupUi(QDialog *new_albums)
    {
        if (new_albums->objectName().isEmpty())
            new_albums->setObjectName(QString::fromUtf8("new_albums"));
        new_albums->resize(602, 191);
        QPalette palette;
        QBrush brush(QColor(250, 223, 211, 255));
        brush.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Base, brush);
        QBrush brush1(QColor(250, 164, 154, 255));
        brush1.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Window, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Base, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Window, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Base, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Window, brush1);
        new_albums->setPalette(palette);
        lineEdit_2 = new QLineEdit(new_albums);
        lineEdit_2->setObjectName(QString::fromUtf8("lineEdit_2"));
        lineEdit_2->setGeometry(QRect(190, 80, 361, 20));
        lineEdit_2->setStyleSheet(QString::fromUtf8("QLineEdit{background-color: rgb(250, 222, 210); border-radius: 9px; font: 63 7.5pt \"Sitka Small Semibold\"; color:  rgb(184, 53, 86);}"));
        label = new QLabel(new_albums);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(40, 50, 141, 21));
        label->setStyleSheet(QString::fromUtf8("\n"
"QLabel{font: 63 7.5pt \"Sitka Small Semibold\"; color:  rgb(184, 53, 86);}\n"
""));
        lineEdit = new QLineEdit(new_albums);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(190, 50, 361, 20));
        lineEdit->setStyleSheet(QString::fromUtf8("QLineEdit{background-color: rgb(250, 222, 210); border-radius: 9px; font: 63 7.5pt \"Sitka Small Semibold\"; color:  rgb(184, 53, 86);}"));
        label_2 = new QLabel(new_albums);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(40, 80, 141, 21));
        label_2->setStyleSheet(QString::fromUtf8("\n"
"QLabel{font: 63 7.5pt \"Sitka Small Semibold\"; color:  rgb(184, 53, 86);}\n"
""));
        pushButton_2 = new QPushButton(new_albums);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(310, 120, 131, 41));
        pushButton_2->setStyleSheet(QString::fromUtf8("QPushButton{background-color: rgb(250, 222, 210); border-radius: 9px;}\n"
"QPushButton{font: 63 7.5pt \"Sitka Small Semibold\"; color:  rgb(184, 53, 86);}\n"
"QPushButton:pressed{background-color: rgb(220, 209, 179)}"));
        pushButton = new QPushButton(new_albums);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(160, 120, 131, 41));
        pushButton->setStyleSheet(QString::fromUtf8("QPushButton{background-color: rgb(250, 222, 210); border-radius: 9px;}\n"
"QPushButton{font: 63 7.5pt \"Sitka Small Semibold\"; color:  rgb(184, 53, 86);}\n"
"QPushButton:pressed{background-color: rgb(220, 209, 179)}"));

        retranslateUi(new_albums);

        QMetaObject::connectSlotsByName(new_albums);
    } // setupUi

    void retranslateUi(QDialog *new_albums)
    {
        new_albums->setWindowTitle(QApplication::translate("new_albums", "Dialog", nullptr));
        label->setText(QApplication::translate("new_albums", "Title", nullptr));
        label_2->setText(QApplication::translate("new_albums", "ArtistId", nullptr));
        pushButton_2->setText(QApplication::translate("new_albums", "\320\236\321\202\320\274\320\265\320\275\320\260", nullptr));
        pushButton->setText(QApplication::translate("new_albums", "\320\224\320\276\320\261\320\260\320\262\320\270\321\202\321\214 \320\267\320\260\320\277\320\270\321\201\321\214", nullptr));
    } // retranslateUi

};

namespace Ui {
    class new_albums: public Ui_new_albums {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_NEW_ALBUMS_H
