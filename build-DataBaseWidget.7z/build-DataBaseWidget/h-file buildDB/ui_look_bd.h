/********************************************************************************
** Form generated from reading UI file 'look_bd.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LOOK_BD_H
#define UI_LOOK_BD_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QTableView>

QT_BEGIN_NAMESPACE

class Ui_look_bd
{
public:
    QTableView *tableView;
    QComboBox *tableSelector;

    void setupUi(QDialog *look_bd)
    {
        if (look_bd->objectName().isEmpty())
            look_bd->setObjectName(QString::fromUtf8("look_bd"));
        look_bd->resize(993, 550);
        QPalette palette;
        QBrush brush(QColor(255, 255, 255, 255));
        brush.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Base, brush);
        QBrush brush1(QColor(250, 164, 154, 255));
        brush1.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Window, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Base, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Window, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Base, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Window, brush1);
        look_bd->setPalette(palette);
        tableView = new QTableView(look_bd);
        tableView->setObjectName(QString::fromUtf8("tableView"));
        tableView->setGeometry(QRect(10, 10, 971, 461));
        QPalette palette1;
        QBrush brush2(QColor(250, 244, 241, 255));
        brush2.setStyle(Qt::SolidPattern);
        palette1.setBrush(QPalette::Active, QPalette::Base, brush2);
        palette1.setBrush(QPalette::Inactive, QPalette::Base, brush2);
        palette1.setBrush(QPalette::Disabled, QPalette::Base, brush1);
        tableView->setPalette(palette1);
        tableSelector = new QComboBox(look_bd);
        tableSelector->addItem(QString());
        tableSelector->addItem(QString());
        tableSelector->addItem(QString());
        tableSelector->addItem(QString());
        tableSelector->addItem(QString());
        tableSelector->addItem(QString());
        tableSelector->addItem(QString());
        tableSelector->addItem(QString());
        tableSelector->addItem(QString());
        tableSelector->addItem(QString());
        tableSelector->addItem(QString());
        tableSelector->setObjectName(QString::fromUtf8("tableSelector"));
        tableSelector->setGeometry(QRect(10, 490, 211, 31));
        tableSelector->setStyleSheet(QString::fromUtf8("QComboBox{background-color: rgb(250, 222, 210); border-radius: 9px; font: 63 7.5pt \"Sitka Small Semibold\"; color:  rgb(184, 53, 86);}"));

        retranslateUi(look_bd);

        QMetaObject::connectSlotsByName(look_bd);
    } // setupUi

    void retranslateUi(QDialog *look_bd)
    {
        look_bd->setWindowTitle(QApplication::translate("look_bd", "Dialog", nullptr));
        tableSelector->setItemText(0, QApplication::translate("look_bd", "employees", nullptr));
        tableSelector->setItemText(1, QApplication::translate("look_bd", "customers", nullptr));
        tableSelector->setItemText(2, QApplication::translate("look_bd", "invoices", nullptr));
        tableSelector->setItemText(3, QApplication::translate("look_bd", "invoice_items", nullptr));
        tableSelector->setItemText(4, QApplication::translate("look_bd", "artists", nullptr));
        tableSelector->setItemText(5, QApplication::translate("look_bd", "albums", nullptr));
        tableSelector->setItemText(6, QApplication::translate("look_bd", "media_types", nullptr));
        tableSelector->setItemText(7, QApplication::translate("look_bd", "genres", nullptr));
        tableSelector->setItemText(8, QApplication::translate("look_bd", "tracks", nullptr));
        tableSelector->setItemText(9, QApplication::translate("look_bd", "playlists", nullptr));
        tableSelector->setItemText(10, QApplication::translate("look_bd", "playlist_track", nullptr));

    } // retranslateUi

};

namespace Ui {
    class look_bd: public Ui_look_bd {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LOOK_BD_H
