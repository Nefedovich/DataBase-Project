/********************************************************************************
** Form generated from reading UI file 'statistics_playlist.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_STATISTICS_PLAYLIST_H
#define UI_STATISTICS_PLAYLIST_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_statistics_playlist
{
public:
    QComboBox *comboBox;
    QPushButton *pushButton;

    void setupUi(QDialog *statistics_playlist)
    {
        if (statistics_playlist->objectName().isEmpty())
            statistics_playlist->setObjectName(QString::fromUtf8("statistics_playlist"));
        statistics_playlist->resize(712, 598);
        comboBox = new QComboBox(statistics_playlist);
        comboBox->setObjectName(QString::fromUtf8("comboBox"));
        comboBox->setGeometry(QRect(20, 10, 481, 32));
        pushButton = new QPushButton(statistics_playlist);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(540, 10, 131, 31));

        retranslateUi(statistics_playlist);

        QMetaObject::connectSlotsByName(statistics_playlist);
    } // setupUi

    void retranslateUi(QDialog *statistics_playlist)
    {
        statistics_playlist->setWindowTitle(QApplication::translate("statistics_playlist", "Dialog", nullptr));
        pushButton->setText(QApplication::translate("statistics_playlist", "\320\223\321\200\320\260\321\204\320\270\320\272 ))", nullptr));
    } // retranslateUi

};

namespace Ui {
    class statistics_playlist: public Ui_statistics_playlist {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_STATISTICS_PLAYLIST_H
