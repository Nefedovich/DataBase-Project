/********************************************************************************
** Form generated from reading UI file 'stat_employee_sale.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_STAT_EMPLOYEE_SALE_H
#define UI_STAT_EMPLOYEE_SALE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>

QT_BEGIN_NAMESPACE

class Ui_stat_employee_sale
{
public:

    void setupUi(QDialog *stat_employee_sale)
    {
        if (stat_employee_sale->objectName().isEmpty())
            stat_employee_sale->setObjectName(QString::fromUtf8("stat_employee_sale"));
        stat_employee_sale->resize(400, 300);

        retranslateUi(stat_employee_sale);

        QMetaObject::connectSlotsByName(stat_employee_sale);
    } // setupUi

    void retranslateUi(QDialog *stat_employee_sale)
    {
        stat_employee_sale->setWindowTitle(QApplication::translate("stat_employee_sale", "Dialog", nullptr));
    } // retranslateUi

};

namespace Ui {
    class stat_employee_sale: public Ui_stat_employee_sale {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_STAT_EMPLOYEE_SALE_H
