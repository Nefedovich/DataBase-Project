/********************************************************************************
** Form generated from reading UI file 'look_bd_client.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LOOK_BD_CLIENT_H
#define UI_LOOK_BD_CLIENT_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QTableView>

QT_BEGIN_NAMESPACE

class Ui_look_bd_client
{
public:
    QTableView *tableView;
    QComboBox *tableSelector;

    void setupUi(QDialog *look_bd_client)
    {
        if (look_bd_client->objectName().isEmpty())
            look_bd_client->setObjectName(QString::fromUtf8("look_bd_client"));
        look_bd_client->resize(996, 539);
        QPalette palette;
        QBrush brush(QColor(250, 244, 241, 255));
        brush.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Base, brush);
        QBrush brush1(QColor(250, 164, 154, 255));
        brush1.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Window, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Base, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Window, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Base, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Window, brush1);
        look_bd_client->setPalette(palette);
        tableView = new QTableView(look_bd_client);
        tableView->setObjectName(QString::fromUtf8("tableView"));
        tableView->setGeometry(QRect(10, 10, 971, 461));
        tableSelector = new QComboBox(look_bd_client);
        tableSelector->addItem(QString());
        tableSelector->addItem(QString());
        tableSelector->addItem(QString());
        tableSelector->addItem(QString());
        tableSelector->addItem(QString());
        tableSelector->addItem(QString());
        tableSelector->addItem(QString());
        tableSelector->addItem(QString());
        tableSelector->addItem(QString());
        tableSelector->setObjectName(QString::fromUtf8("tableSelector"));
        tableSelector->setGeometry(QRect(10, 490, 211, 31));
        tableSelector->setStyleSheet(QString::fromUtf8("QComboBox{background-color: rgb(250, 222, 210); border-radius: 9px; font: 63 7.5pt \"Sitka Small Semibold\"; color:  rgb(184, 53, 86);}\n"
"\n"
";"));

        retranslateUi(look_bd_client);

        QMetaObject::connectSlotsByName(look_bd_client);
    } // setupUi

    void retranslateUi(QDialog *look_bd_client)
    {
        look_bd_client->setWindowTitle(QApplication::translate("look_bd_client", "Dialog", nullptr));
        tableSelector->setItemText(0, QApplication::translate("look_bd_client", "invoices", nullptr));
        tableSelector->setItemText(1, QApplication::translate("look_bd_client", "invoice_items", nullptr));
        tableSelector->setItemText(2, QApplication::translate("look_bd_client", "artists", nullptr));
        tableSelector->setItemText(3, QApplication::translate("look_bd_client", "albums", nullptr));
        tableSelector->setItemText(4, QApplication::translate("look_bd_client", "media_types", nullptr));
        tableSelector->setItemText(5, QApplication::translate("look_bd_client", "genres", nullptr));
        tableSelector->setItemText(6, QApplication::translate("look_bd_client", "tracks", nullptr));
        tableSelector->setItemText(7, QApplication::translate("look_bd_client", "playlists", nullptr));
        tableSelector->setItemText(8, QApplication::translate("look_bd_client", "playlist_track", nullptr));

    } // retranslateUi

};

namespace Ui {
    class look_bd_client: public Ui_look_bd_client {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LOOK_BD_CLIENT_H
