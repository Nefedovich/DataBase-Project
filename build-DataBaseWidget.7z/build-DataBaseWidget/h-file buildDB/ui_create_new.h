/********************************************************************************
** Form generated from reading UI file 'create_new.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CREATE_NEW_H
#define UI_CREATE_NEW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_create_new
{
public:
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;
    QPushButton *pushButton_5;
    QPushButton *pushButton_6;
    QPushButton *pushButton_7;
    QLineEdit *lineEdit;

    void setupUi(QDialog *create_new)
    {
        if (create_new->objectName().isEmpty())
            create_new->setObjectName(QString::fromUtf8("create_new"));
        create_new->resize(480, 258);
        QPalette palette;
        QBrush brush(QColor(255, 255, 255, 255));
        brush.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Base, brush);
        QBrush brush1(QColor(250, 164, 154, 255));
        brush1.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Window, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Base, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Window, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Base, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Window, brush1);
        create_new->setPalette(palette);
        pushButton = new QPushButton(create_new);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(180, 90, 111, 41));
        pushButton->setCursor(QCursor(Qt::PointingHandCursor));
        pushButton->setStyleSheet(QString::fromUtf8("QPushButton{background-color: rgb(250, 222, 210); border-radius: 9px;}\n"
"QPushButton{font: 63 7.5pt \"Sitka Small Semibold\"; color:  rgb(184, 53, 86);}\n"
"QPushButton:pressed{background-color: rgb(220, 209, 179)}"));
        pushButton_2 = new QPushButton(create_new);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(300, 140, 111, 41));
        pushButton_2->setCursor(QCursor(Qt::PointingHandCursor));
        pushButton_2->setStyleSheet(QString::fromUtf8("QPushButton{background-color: rgb(250, 222, 210); border-radius: 9px;}\n"
"QPushButton{font: 63 7.5pt \"Sitka Small Semibold\"; color:  rgb(184, 53, 86);}\n"
"QPushButton:pressed{background-color: rgb(220, 209, 179)}"));
        pushButton_3 = new QPushButton(create_new);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setGeometry(QRect(60, 90, 111, 41));
        pushButton_3->setCursor(QCursor(Qt::PointingHandCursor));
        pushButton_3->setStyleSheet(QString::fromUtf8("QPushButton{background-color: rgb(250, 222, 210); border-radius: 9px;}\n"
"QPushButton{font: 63 7.5pt \"Sitka Small Semibold\"; color:  rgb(184, 53, 86);}\n"
"QPushButton:pressed{background-color: rgb(220, 209, 179)}"));
        pushButton_4 = new QPushButton(create_new);
        pushButton_4->setObjectName(QString::fromUtf8("pushButton_4"));
        pushButton_4->setGeometry(QRect(60, 140, 111, 41));
        pushButton_4->setCursor(QCursor(Qt::PointingHandCursor));
        pushButton_4->setStyleSheet(QString::fromUtf8("QPushButton{background-color: rgb(250, 222, 210); border-radius: 9px;}\n"
"QPushButton{font: 63 7.5pt \"Sitka Small Semibold\"; color:  rgb(184, 53, 86);}\n"
"QPushButton:pressed{background-color: rgb(220, 209, 179)}"));
        pushButton_5 = new QPushButton(create_new);
        pushButton_5->setObjectName(QString::fromUtf8("pushButton_5"));
        pushButton_5->setGeometry(QRect(180, 140, 111, 41));
        pushButton_5->setCursor(QCursor(Qt::PointingHandCursor));
        pushButton_5->setStyleSheet(QString::fromUtf8("QPushButton{background-color: rgb(250, 222, 210); border-radius: 9px;}\n"
"QPushButton{font: 63 7.5pt \"Sitka Small Semibold\"; color:  rgb(184, 53, 86);}\n"
"QPushButton:pressed{background-color: rgb(220, 209, 179)}"));
        pushButton_6 = new QPushButton(create_new);
        pushButton_6->setObjectName(QString::fromUtf8("pushButton_6"));
        pushButton_6->setGeometry(QRect(180, 190, 111, 41));
        pushButton_6->setCursor(QCursor(Qt::PointingHandCursor));
        pushButton_6->setStyleSheet(QString::fromUtf8("QPushButton{background-color: rgb(250, 222, 210); border-radius: 9px;}\n"
"QPushButton{font: 63 7.5pt \"Sitka Small Semibold\"; color:  rgb(184, 53, 86);}\n"
"QPushButton:pressed{background-color: rgb(220, 209, 179)}"));
        pushButton_7 = new QPushButton(create_new);
        pushButton_7->setObjectName(QString::fromUtf8("pushButton_7"));
        pushButton_7->setGeometry(QRect(300, 90, 111, 41));
        pushButton_7->setCursor(QCursor(Qt::PointingHandCursor));
        pushButton_7->setStyleSheet(QString::fromUtf8("QPushButton{background-color: rgb(250, 222, 210); border-radius: 9px;}\n"
"QPushButton{font: 63 7.5pt \"Sitka Small Semibold\"; color:  rgb(184, 53, 86);}\n"
"QPushButton:pressed{background-color: rgb(220, 209, 179)}"));
        lineEdit = new QLineEdit(create_new);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(60, 20, 351, 41));
        lineEdit->setLayoutDirection(Qt::LeftToRight);
        lineEdit->setStyleSheet(QString::fromUtf8("QLineEdit{background-color: rgb(255, 237, 235); border-radius: 6.5px;}\n"
"QLineEdit{font: 63 8pt \"Sitka Small Semibold\"; color:  rgb(119, 34, 56);}"));
        lineEdit->setFrame(true);
        lineEdit->setReadOnly(true);

        retranslateUi(create_new);

        QMetaObject::connectSlotsByName(create_new);
    } // setupUi

    void retranslateUi(QDialog *create_new)
    {
        create_new->setWindowTitle(QApplication::translate("create_new", "Dialog", nullptr));
        pushButton->setText(QApplication::translate("create_new", "employees", nullptr));
        pushButton_2->setText(QApplication::translate("create_new", "customers", nullptr));
        pushButton_3->setText(QApplication::translate("create_new", "invoices", nullptr));
        pushButton_4->setText(QApplication::translate("create_new", "albums", nullptr));
        pushButton_5->setText(QApplication::translate("create_new", "invoice_items", nullptr));
        pushButton_6->setText(QApplication::translate("create_new", "tracks", nullptr));
        pushButton_7->setText(QApplication::translate("create_new", "artists", nullptr));
        lineEdit->setText(QApplication::translate("create_new", "         \320\232\321\203\320\264\320\260 \320\275\320\265\320\276\320\261\321\205\320\276\320\264\320\270\320\274\320\276 \320\264\320\276\320\261\320\260\320\262\320\270\321\202\321\214 \321\201\321\202\321\200\320\276\320\272\321\203?", nullptr));
    } // retranslateUi

};

namespace Ui {
    class create_new: public Ui_create_new {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CREATE_NEW_H
