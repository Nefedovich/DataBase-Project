/********************************************************************************
** Form generated from reading UI file 'employee.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_EMPLOYEE_H
#define UI_EMPLOYEE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_employee
{
public:
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;

    void setupUi(QDialog *employee)
    {
        if (employee->objectName().isEmpty())
            employee->setObjectName(QString::fromUtf8("employee"));
        employee->resize(400, 231);
        QPalette palette;
        QBrush brush(QColor(255, 255, 255, 255));
        brush.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Base, brush);
        QBrush brush1(QColor(250, 164, 154, 255));
        brush1.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Window, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Base, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Window, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Base, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Window, brush1);
        employee->setPalette(palette);
        pushButton = new QPushButton(employee);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(50, 20, 311, 41));
        pushButton->setCursor(QCursor(Qt::PointingHandCursor));
        pushButton->setStyleSheet(QString::fromUtf8("QPushButton{background-color: rgb(250, 222, 210); border-radius: 9px;}\n"
"QPushButton{font: 63 7.5pt \"Sitka Small Semibold\"; color:  rgb(184, 53, 86);}\n"
"QPushButton:pressed{background-color: rgb(220, 209, 179)}"));
        pushButton_2 = new QPushButton(employee);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(50, 70, 311, 41));
        pushButton_2->setCursor(QCursor(Qt::PointingHandCursor));
        pushButton_2->setStyleSheet(QString::fromUtf8("QPushButton{background-color: rgb(250, 222, 210); border-radius: 9px;}\n"
"QPushButton{font: 63 7.5pt \"Sitka Small Semibold\"; color:  rgb(184, 53, 86);}\n"
"QPushButton:pressed{background-color: rgb(220, 209, 179)}"));
        pushButton_3 = new QPushButton(employee);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setGeometry(QRect(50, 120, 311, 41));
        pushButton_3->setCursor(QCursor(Qt::PointingHandCursor));
        pushButton_3->setStyleSheet(QString::fromUtf8("QPushButton{background-color: rgb(250, 222, 210); border-radius: 9px;}\n"
"QPushButton{font: 63 7.5pt \"Sitka Small Semibold\"; color:  rgb(184, 53, 86);}\n"
"QPushButton:pressed{background-color: rgb(220, 209, 179)}"));
        pushButton_4 = new QPushButton(employee);
        pushButton_4->setObjectName(QString::fromUtf8("pushButton_4"));
        pushButton_4->setGeometry(QRect(50, 170, 311, 41));
        pushButton_4->setCursor(QCursor(Qt::PointingHandCursor));
        pushButton_4->setStyleSheet(QString::fromUtf8("QPushButton{background-color: rgb(250, 222, 210); border-radius: 9px;}\n"
"QPushButton{font: 63 7.5pt \"Sitka Small Semibold\"; color:  rgb(184, 53, 86);}\n"
"QPushButton:pressed{background-color: rgb(220, 209, 179)}"));

        retranslateUi(employee);

        QMetaObject::connectSlotsByName(employee);
    } // setupUi

    void retranslateUi(QDialog *employee)
    {
        employee->setWindowTitle(QApplication::translate("employee", "Dialog", nullptr));
        pushButton->setText(QApplication::translate("employee", "\320\237\320\276\321\201\320\274\320\276\321\202\321\200\320\265\321\202\321\214 \320\270\320\275\321\204\320\276\321\200\320\274\320\260\321\206\320\270\321\216 \320\270\320\267 \320\261\320\260\320\267\321\213 \320\264\320\260\320\275\320\275\321\213\321\205", nullptr));
        pushButton_2->setText(QApplication::translate("employee", "\320\241\320\276\320\267\320\264\320\260\321\202\321\214 \320\275\320\276\320\262\321\203\321\216 \321\201\321\202\321\200\320\276\320\272\321\203", nullptr));
        pushButton_3->setText(QApplication::translate("employee", "\320\237\320\276\320\270\321\201\320\272 \320\277\320\276 \320\261\320\260\320\267\320\265 \320\264\320\260\320\275\320\275\321\213\321\205", nullptr));
        pushButton_4->setText(QApplication::translate("employee", "\320\241\321\202\320\260\321\202\320\270\321\201\321\202\320\270\320\272\320\260", nullptr));
    } // retranslateUi

};

namespace Ui {
    class employee: public Ui_employee {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_EMPLOYEE_H
