/********************************************************************************
** Form generated from reading UI file 'statictics_genres.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_STATICTICS_GENRES_H
#define UI_STATICTICS_GENRES_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>

QT_BEGIN_NAMESPACE

class Ui_statictics_genres
{
public:

    void setupUi(QDialog *statictics_genres)
    {
        if (statictics_genres->objectName().isEmpty())
            statictics_genres->setObjectName(QString::fromUtf8("statictics_genres"));
        statictics_genres->resize(400, 300);

        retranslateUi(statictics_genres);

        QMetaObject::connectSlotsByName(statictics_genres);
    } // setupUi

    void retranslateUi(QDialog *statictics_genres)
    {
        statictics_genres->setWindowTitle(QApplication::translate("statictics_genres", "Dialog", nullptr));
    } // retranslateUi

};

namespace Ui {
    class statictics_genres: public Ui_statictics_genres {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_STATICTICS_GENRES_H
