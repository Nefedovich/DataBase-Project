/********************************************************************************
** Form generated from reading UI file 'find_bd.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FIND_BD_H
#define UI_FIND_BD_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableView>

QT_BEGIN_NAMESPACE

class Ui_find_bd
{
public:
    QComboBox *comboBox_searchType;
    QComboBox *comboBox_searchValue;
    QPushButton *pushButton_search;
    QPushButton *pushButton_2;
    QTableView *tableView_results;
    QLabel *label;

    void setupUi(QDialog *find_bd)
    {
        if (find_bd->objectName().isEmpty())
            find_bd->setObjectName(QString::fromUtf8("find_bd"));
        find_bd->resize(902, 698);
        QPalette palette;
        QBrush brush(QColor(255, 255, 255, 255));
        brush.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Base, brush);
        QBrush brush1(QColor(250, 164, 154, 255));
        brush1.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Window, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Base, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Window, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Base, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Window, brush1);
        find_bd->setPalette(palette);
        find_bd->setStyleSheet(QString::fromUtf8("QPushButton{background-color: rgb(250, 222, 210); border-radius: 9px;}\n"
"QPushButton{font: 63 7.5pt \"Sitka Small Semibold\"; color:  rgb(184, 53, 86);}\n"
"QPushButton:pressed{background-color: rgb(220, 209, 179)}\n"
"\n"
"QLineEdit{background-color: rgb(250, 244, 241); border-radius: 9px; font: 63 7.5pt \"Sitka Small Semibold\"; color:  rgb(184, 53, 86);}\n"
"\n"
"QLabel{font: 63 7.5pt \"Sitka Small Semibold\"; color:  rgb(184, 53, 86);}"));
        comboBox_searchType = new QComboBox(find_bd);
        comboBox_searchType->setObjectName(QString::fromUtf8("comboBox_searchType"));
        comboBox_searchType->setGeometry(QRect(560, 60, 241, 22));
        comboBox_searchType->setStyleSheet(QString::fromUtf8("QComboBox{background-color: rgb(250, 222, 210); border-radius: 9px;}\n"
"QComboBox{font: 63 7.5pt \"Sitka Small Semibold\"; color:  rgb(184, 53, 86);}"));
        comboBox_searchValue = new QComboBox(find_bd);
        comboBox_searchValue->setObjectName(QString::fromUtf8("comboBox_searchValue"));
        comboBox_searchValue->setGeometry(QRect(560, 90, 241, 22));
        comboBox_searchValue->setStyleSheet(QString::fromUtf8("QComboBox{background-color: rgb(250, 222, 210); border-radius: 9px;}\n"
"QComboBox{font: 63 7.5pt \"Sitka Small Semibold\"; color:  rgb(184, 53, 86);}"));
        pushButton_search = new QPushButton(find_bd);
        pushButton_search->setObjectName(QString::fromUtf8("pushButton_search"));
        pushButton_search->setGeometry(QRect(580, 130, 75, 23));
        pushButton_search->setStyleSheet(QString::fromUtf8("QPushButton{background-color: rgb(250, 222, 210); border-radius: 9px;}\n"
"QPushButton{font: 63 7.5pt \"Sitka Small Semibold\"; color:  rgb(184, 53, 86);}\n"
"QPushButton:pressed{background-color: rgb(220, 209, 179)}"));
        pushButton_2 = new QPushButton(find_bd);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(670, 130, 75, 23));
        pushButton_2->setStyleSheet(QString::fromUtf8("QPushButton{background-color: rgb(250, 222, 210); border-radius: 9px;}\n"
"QPushButton{font: 63 7.5pt \"Sitka Small Semibold\"; color:  rgb(184, 53, 86);}\n"
"QPushButton:pressed{background-color: rgb(220, 209, 179)}"));
        tableView_results = new QTableView(find_bd);
        tableView_results->setObjectName(QString::fromUtf8("tableView_results"));
        tableView_results->setGeometry(QRect(80, 220, 721, 451));
        tableView_results->setStyleSheet(QString::fromUtf8("QTableView{background-color: rgb(250, 244, 241)}"));
        label = new QLabel(find_bd);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(80, 200, 141, 17));

        retranslateUi(find_bd);

        QMetaObject::connectSlotsByName(find_bd);
    } // setupUi

    void retranslateUi(QDialog *find_bd)
    {
        find_bd->setWindowTitle(QApplication::translate("find_bd", "Dialog", nullptr));
        pushButton_search->setText(QApplication::translate("find_bd", "\320\235\320\260\320\271\321\202\320\270", nullptr));
        pushButton_2->setText(QApplication::translate("find_bd", "\320\236\321\202\320\274\320\265\320\275\320\260", nullptr));
        label->setText(QApplication::translate("find_bd", "\320\240\320\265\320\267\321\203\320\273\321\214\321\202\320\260\321\202 \320\277\320\276\320\270\321\201\320\272\320\260:", nullptr));
    } // retranslateUi

};

namespace Ui {
    class find_bd: public Ui_find_bd {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FIND_BD_H
