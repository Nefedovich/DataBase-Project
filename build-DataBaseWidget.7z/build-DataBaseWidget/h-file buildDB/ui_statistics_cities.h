/********************************************************************************
** Form generated from reading UI file 'statistics_cities.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_STATISTICS_CITIES_H
#define UI_STATISTICS_CITIES_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>

QT_BEGIN_NAMESPACE

class Ui_statistics_cities
{
public:

    void setupUi(QDialog *statistics_cities)
    {
        if (statistics_cities->objectName().isEmpty())
            statistics_cities->setObjectName(QString::fromUtf8("statistics_cities"));
        statistics_cities->resize(400, 300);

        retranslateUi(statistics_cities);

        QMetaObject::connectSlotsByName(statistics_cities);
    } // setupUi

    void retranslateUi(QDialog *statistics_cities)
    {
        statistics_cities->setWindowTitle(QApplication::translate("statistics_cities", "Dialog", nullptr));
    } // retranslateUi

};

namespace Ui {
    class statistics_cities: public Ui_statistics_cities {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_STATISTICS_CITIES_H
