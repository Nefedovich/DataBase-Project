/********************************************************************************
** Form generated from reading UI file 'new_employee.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_NEW_EMPLOYEE_H
#define UI_NEW_EMPLOYEE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_new_employee
{
public:
    QLineEdit *lineEdit;
    QLineEdit *lineEdit_2;
    QLineEdit *lineEdit_3;
    QLineEdit *lineEdit_4;
    QLineEdit *lineEdit_5;
    QLineEdit *lineEdit_6;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *label_6;
    QPushButton *pushButton_2;
    QPushButton *pushButton;
    QLabel *label_7;
    QLineEdit *lineEdit_7;
    QLineEdit *lineEdit_10;
    QLabel *label_11;
    QLabel *label_8;
    QLabel *label_9;
    QLineEdit *lineEdit_8;
    QLineEdit *lineEdit_11;
    QLabel *label_10;
    QLabel *label_12;
    QLineEdit *lineEdit_9;
    QLineEdit *lineEdit_12;
    QLabel *label_13;
    QLabel *label_14;
    QLineEdit *lineEdit_13;
    QLineEdit *lineEdit_14;

    void setupUi(QDialog *new_employee)
    {
        if (new_employee->objectName().isEmpty())
            new_employee->setObjectName(QString::fromUtf8("new_employee"));
        new_employee->resize(615, 564);
        QPalette palette;
        QBrush brush(QColor(250, 244, 241, 255));
        brush.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Base, brush);
        QBrush brush1(QColor(250, 164, 154, 255));
        brush1.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Window, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Base, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Window, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Base, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Window, brush1);
        new_employee->setPalette(palette);
        new_employee->setStyleSheet(QString::fromUtf8("QPushButton{background-color: rgb(250, 222, 210); border-radius: 9px;}\n"
"QPushButton{font: 63 7.5pt \"Sitka Small Semibold\"; color:  rgb(184, 53, 86);}\n"
"QPushButton:pressed{background-color: rgb(220, 209, 179)}\n"
"\n"
"QLineEdit{background-color: rgb(250, 222, 210); border-radius: 9px; font: 63 7.5pt \"Sitka Small Semibold\"; color:  rgb(184, 53, 86);}\n"
"\n"
"QLabel{font: 63 7.5pt \"Sitka Small Semibold\"; color:  rgb(184, 53, 86);}"));
        lineEdit = new QLineEdit(new_employee);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(200, 50, 361, 20));
        lineEdit_2 = new QLineEdit(new_employee);
        lineEdit_2->setObjectName(QString::fromUtf8("lineEdit_2"));
        lineEdit_2->setGeometry(QRect(200, 80, 361, 20));
        lineEdit_3 = new QLineEdit(new_employee);
        lineEdit_3->setObjectName(QString::fromUtf8("lineEdit_3"));
        lineEdit_3->setGeometry(QRect(200, 110, 361, 20));
        lineEdit_4 = new QLineEdit(new_employee);
        lineEdit_4->setObjectName(QString::fromUtf8("lineEdit_4"));
        lineEdit_4->setGeometry(QRect(200, 170, 361, 20));
        lineEdit_5 = new QLineEdit(new_employee);
        lineEdit_5->setObjectName(QString::fromUtf8("lineEdit_5"));
        lineEdit_5->setGeometry(QRect(200, 200, 361, 20));
        lineEdit_6 = new QLineEdit(new_employee);
        lineEdit_6->setObjectName(QString::fromUtf8("lineEdit_6"));
        lineEdit_6->setGeometry(QRect(200, 230, 361, 20));
        label = new QLabel(new_employee);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(50, 50, 141, 21));
        label_2 = new QLabel(new_employee);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(50, 80, 141, 21));
        label_3 = new QLabel(new_employee);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(50, 110, 141, 21));
        label_4 = new QLabel(new_employee);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(50, 170, 141, 21));
        label_5 = new QLabel(new_employee);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(50, 200, 141, 21));
        label_6 = new QLabel(new_employee);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(50, 230, 141, 21));
        pushButton_2 = new QPushButton(new_employee);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(290, 500, 131, 41));
        pushButton = new QPushButton(new_employee);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(140, 500, 131, 41));
        label_7 = new QLabel(new_employee);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(50, 140, 141, 21));
        lineEdit_7 = new QLineEdit(new_employee);
        lineEdit_7->setObjectName(QString::fromUtf8("lineEdit_7"));
        lineEdit_7->setGeometry(QRect(200, 140, 361, 20));
        lineEdit_10 = new QLineEdit(new_employee);
        lineEdit_10->setObjectName(QString::fromUtf8("lineEdit_10"));
        lineEdit_10->setGeometry(QRect(200, 320, 361, 20));
        label_11 = new QLabel(new_employee);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        label_11->setGeometry(QRect(50, 350, 141, 21));
        label_8 = new QLabel(new_employee);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setGeometry(QRect(50, 380, 141, 21));
        label_9 = new QLabel(new_employee);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setGeometry(QRect(50, 260, 141, 21));
        lineEdit_8 = new QLineEdit(new_employee);
        lineEdit_8->setObjectName(QString::fromUtf8("lineEdit_8"));
        lineEdit_8->setGeometry(QRect(200, 290, 361, 20));
        lineEdit_11 = new QLineEdit(new_employee);
        lineEdit_11->setObjectName(QString::fromUtf8("lineEdit_11"));
        lineEdit_11->setGeometry(QRect(200, 350, 361, 20));
        label_10 = new QLabel(new_employee);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setGeometry(QRect(50, 320, 141, 21));
        label_12 = new QLabel(new_employee);
        label_12->setObjectName(QString::fromUtf8("label_12"));
        label_12->setGeometry(QRect(50, 410, 141, 21));
        lineEdit_9 = new QLineEdit(new_employee);
        lineEdit_9->setObjectName(QString::fromUtf8("lineEdit_9"));
        lineEdit_9->setGeometry(QRect(200, 410, 361, 20));
        lineEdit_12 = new QLineEdit(new_employee);
        lineEdit_12->setObjectName(QString::fromUtf8("lineEdit_12"));
        lineEdit_12->setGeometry(QRect(200, 440, 361, 20));
        label_13 = new QLabel(new_employee);
        label_13->setObjectName(QString::fromUtf8("label_13"));
        label_13->setGeometry(QRect(50, 290, 141, 21));
        label_14 = new QLabel(new_employee);
        label_14->setObjectName(QString::fromUtf8("label_14"));
        label_14->setGeometry(QRect(50, 440, 141, 21));
        lineEdit_13 = new QLineEdit(new_employee);
        lineEdit_13->setObjectName(QString::fromUtf8("lineEdit_13"));
        lineEdit_13->setGeometry(QRect(200, 380, 361, 20));
        lineEdit_14 = new QLineEdit(new_employee);
        lineEdit_14->setObjectName(QString::fromUtf8("lineEdit_14"));
        lineEdit_14->setGeometry(QRect(200, 260, 361, 20));

        retranslateUi(new_employee);

        QMetaObject::connectSlotsByName(new_employee);
    } // setupUi

    void retranslateUi(QDialog *new_employee)
    {
        new_employee->setWindowTitle(QApplication::translate("new_employee", "Dialog", nullptr));
        label->setText(QApplication::translate("new_employee", "Last Name", nullptr));
        label_2->setText(QApplication::translate("new_employee", "First Name", nullptr));
        label_3->setText(QApplication::translate("new_employee", "Title", nullptr));
        label_4->setText(QApplication::translate("new_employee", "Birth Date", nullptr));
        label_5->setText(QApplication::translate("new_employee", "Hire Date", nullptr));
        label_6->setText(QApplication::translate("new_employee", "Adress", nullptr));
        pushButton_2->setText(QApplication::translate("new_employee", "\320\236\321\202\320\274\320\265\320\275\320\260", nullptr));
        pushButton->setText(QApplication::translate("new_employee", "\320\224\320\276\320\261\320\260\320\262\320\270\321\202\321\214 \320\267\320\260\320\277\320\270\321\201\321\214", nullptr));
        label_7->setText(QApplication::translate("new_employee", "Reports To", nullptr));
        label_11->setText(QApplication::translate("new_employee", "Postal Code", nullptr));
        label_8->setText(QApplication::translate("new_employee", "Phone", nullptr));
        label_9->setText(QApplication::translate("new_employee", "City", nullptr));
        label_10->setText(QApplication::translate("new_employee", "Country", nullptr));
        label_12->setText(QApplication::translate("new_employee", "Fax", nullptr));
        label_13->setText(QApplication::translate("new_employee", "State", nullptr));
        label_14->setText(QApplication::translate("new_employee", "Email", nullptr));
    } // retranslateUi

};

namespace Ui {
    class new_employee: public Ui_new_employee {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_NEW_EMPLOYEE_H
