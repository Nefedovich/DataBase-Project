#ifndef STATISTICS_H
#define STATISTICS_H

#include <QDialog>
#include "statistics_cities.h"
#include "statictics_genres.h"
#include "statistics_playlist.h"

namespace Ui {
class statistics;
}

class statistics : public QDialog
{
    Q_OBJECT

public:
    explicit statistics(QWidget *parent = nullptr);
    ~statistics();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_4_clicked();

private:
    Ui::statistics *ui;
    statistics_cities *stct;
    statictics_genres *stg;
    statistics_playlist *stpl;

};

#endif // STATISTICS_H
