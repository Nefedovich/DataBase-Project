#ifndef FIND_H
#define FIND_H

#include <QDialog>
#include <QSqlDatabase>
#include <QSqlQueryModel>

namespace Ui {
class Find;
}

class Find : public QDialog
{
    Q_OBJECT

public:
    explicit Find(QWidget *parent = nullptr);
    ~Find();

private:
    void openDatabase(const QString &dbPath);

    Ui::Find *ui;
    QSqlDatabase db;
};

#endif // FIND_H
