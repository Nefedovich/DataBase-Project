#ifndef CLIENT_H
#define CLIENT_H

#include <QDialog>
#include "look_bd_client.h"
#include "find_bd.h"
#include "new_playlist.h"
#include "statistics.h"

namespace Ui {
class client;
}

class client : public QDialog
{
    Q_OBJECT

public:
    explicit client(QWidget *parent = nullptr);
    ~client();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();

private:
    Ui::client *ui;
    look_bd_client *window;
    find_bd *f;
    new_playlist *np;
    statistics *st;
};

#endif // CLIENT_H
