#ifndef LOOK_BD_H
#define LOOK_BD_H

#include <QDialog>
#include <QSqlDatabase>
#include <QSqlQueryModel>

namespace Ui {
class look_bd;
}

class look_bd : public QDialog
{
    Q_OBJECT

public:
    explicit look_bd(QWidget *parent = nullptr);
    ~look_bd();

private:
    void openDatabase(const QString &dbPath);
    void loadTable(const QString &tableName);

    Ui::look_bd *ui;
    QSqlDatabase db;

private slots:
    void onTableChanged(const QString &tableName);
};

#endif // LOOK_BD_H
