#ifndef FIND_EMP_H
#define FIND_EMP_H

#include <QDialog>
#include <QSqlDatabase>
#include <QSqlQueryModel>

namespace Ui {
class find_emp;
}

class find_emp : public QDialog
{
    Q_OBJECT

public:
    explicit find_emp(QWidget *parent = nullptr);
    ~find_emp();

private:
    void openDatabase(const QString &dbPath);

    Ui::find_emp *ui;
    QSqlDatabase db;

    void search();
    void searchInvoices();

private slots:
    void on_pushButton_search_clicked();
    void on_pushButton_2_clicked();
};

#endif // FIND_EMP_H
