#ifndef STAT_EMPLOYEE_SALE_H
#define STAT_EMPLOYEE_SALE_H

#include <QDialog>
#include <QMessageBox>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
#include <QSqlDatabase>
#include <QSqlQueryModel>

namespace Ui {
class stat_employee_sale;
}

class stat_employee_sale : public QDialog
{
    Q_OBJECT

public:
    explicit stat_employee_sale(QWidget *parent = nullptr);
    ~stat_employee_sale();
    void openDatabase(const QString &dbPath);

private:
    QSqlDatabase db;
    Ui::stat_employee_sale *ui;
};

#endif // STAT_EMPLOYEE_SALE_H
