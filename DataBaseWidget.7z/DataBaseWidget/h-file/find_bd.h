#ifndef FIND_BD_H
#define FIND_BD_H

#include <QDialog>
#include <QSqlDatabase>
#include <QSqlQueryModel>

namespace Ui {
class find_bd;
}

class find_bd : public QDialog
{
    Q_OBJECT

public:
    explicit find_bd(QWidget *parent = nullptr);
    ~find_bd();

private:
    void openDatabase(const QString &dbPath);

    Ui::find_bd *ui;
    QSqlDatabase db;

    void populateSearchValues();
    void search();

private slots:
    void on_comboBox_searchType_currentIndexChanged(int index);
    void on_pushButton_search_clicked();
    void on_pushButton_2_clicked();
};

#endif // FIND_BD_H
