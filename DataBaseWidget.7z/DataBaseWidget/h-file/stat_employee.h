#ifndef STAT_EMPLOYEE_H
#define STAT_EMPLOYEE_H

#include <QDialog>
#include "stat_employee_sale.h"

namespace Ui {
class stat_employee;
}

class stat_employee : public QDialog
{
    Q_OBJECT

public:
    explicit stat_employee(QWidget *parent = nullptr);
    ~stat_employee();

private slots:
    void on_pushButton_clicked();

private:
    Ui::stat_employee *ui;
    stat_employee_sale *stsale;
};

#endif // STAT_EMPLOYEE_H
