#ifndef NEW_ARTISTS_H
#define NEW_ARTISTS_H

#include <QDialog>
#include <QMessageBox>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
#include <QSqlDatabase>
#include <QSqlQueryModel>

namespace Ui {
class new_artists;
}

class new_artists : public QDialog
{
    Q_OBJECT

public:
    explicit new_artists(QWidget *parent = nullptr);
    ~new_artists();

private slots:
    void on_pushButton_2_clicked();

    void on_pushButton_clicked();

private:
    void openDatabase(const QString &dbPath);

    Ui::new_artists *ui;
    QSqlDatabase db;
};

#endif // NEW_ARTISTS_H
