#ifndef STATISTICS_PLAYLIST_H
#define STATISTICS_PLAYLIST_H

#include <QDialog>
#include <QMessageBox>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
#include <QSqlDatabase>

namespace Ui {
class statistics_playlist;
}

class statistics_playlist : public QDialog
{
    Q_OBJECT

public:
    explicit statistics_playlist(QWidget *parent = nullptr);
    ~statistics_playlist();
    void openDatabase(const QString &dbPath);
    void playlistValues();

private slots:
    void on_pushButton_clicked();

private:
    Ui::statistics_playlist *ui;
    QSqlDatabase db;
};

#endif // STATISTICS_PLAYLIST_H
