#ifndef NEW_INVOICES_BD_H
#define NEW_INVOICES_BD_H

#include <QDialog>
#include <QMessageBox>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
#include <QSqlDatabase>
#include <QSqlQueryModel>

namespace Ui {
class new_invoices_bd;
}

class new_invoices_bd : public QDialog
{
    Q_OBJECT

public:
    explicit new_invoices_bd(QWidget *parent = nullptr);
    ~new_invoices_bd();

private slots:
    void on_pushButton_2_clicked();

    void on_pushButton_clicked();

private:
    void openDatabase(const QString &dbPath);
    Ui::new_invoices_bd *ui;
    QSqlDatabase db;
};

#endif // NEW_INVOICES_BD_H
