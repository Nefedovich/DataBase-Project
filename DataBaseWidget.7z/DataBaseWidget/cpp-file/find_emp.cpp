#include "find_emp.h"
#include "ui_find_emp.h"
#include <QSqlQuery>
#include <QSqlQueryModel>
#include <QMessageBox>
#include <QSqlError>

find_emp::find_emp(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::find_emp)
{
    ui->setupUi(this);
    openDatabase("/Users/test/Documents/Qt/DataBaseWidget/chinook.db");

    ui->comboBox_searchType->addItem("Сотрудник");
    ui->comboBox_searchType->addItem("Клиент");

    connect(ui->comboBox_searchType, SIGNAL(currentIndexChanged(int)), this, SLOT(on_comboBox_searchType_currentIndexChanged(int)));
    connect(ui->pushButton_search, SIGNAL(clicked()), this, SLOT(on_pushButton_search_clicked()));
}

find_emp::~find_emp()
{
    db.close();
    delete ui;
}

void find_emp::openDatabase(const QString &dbPath)
{

    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName(dbPath);

    if (!db.open()) {
        printf("Ошибка открытия базы данных");
    }
}

void find_emp::on_pushButton_search_clicked()
{
    search();
    searchInvoices();
}

void find_emp::search()
{
    QString searchType = ui->comboBox_searchType->currentText(); // Получаем выбранный тип поиска
        QString firstName = ui->lineEdit_firstName->text(); // Получаем введенное имя
        QString lastName = ui->lineEdit_lastName->text(); // Получаем введенную фамилию

        // Проверка на пустое значение
        if (firstName.isEmpty() || lastName.isEmpty()) {
            QMessageBox::warning(this, "Ошибка", "Пожалуйста, введите имя и фамилию.");
            return;
        }

        QSqlQuery query(db);
        QSqlQueryModel *model = new QSqlQueryModel(this); // Создаем модель один раз

        if (searchType == "Сотрудник") {
            // Поиск сотрудника по имени и фамилии
            query.prepare("SELECT EmployeeId, FirstName, LastName, Title, Address "
                          "FROM employees "
                          "WHERE FirstName = :firstName AND LastName = :lastName");
        } else if (searchType == "Клиент") {
            // Поиск клиента по имени и фамилии
            query.prepare("SELECT CustomerId, FirstName, LastName, Company, Address, City "
                          "FROM customers "
                          "WHERE FirstName = :firstName AND LastName = :lastName");
        } else {
            QMessageBox::warning(this, "Ошибка", "Неизвестный тип поиска.");
            return;
        }

        query.bindValue(":firstName", firstName);
        query.bindValue(":lastName", lastName);

        // Выполнение запроса
        if (query.exec()) {
            model->setQuery(query);
            if (model->rowCount() == 0) {
                QMessageBox::information(this, "Результаты", "Нет результатов для отображения.");
            } else {
                ui->tableView_results->setModel(model);
            }
        } else {
            QMessageBox::warning(this, "Ошибка", "Не удалось выполнить запрос: " + query.lastError().text());
        }
}

void find_emp::searchInvoices()
{
    QString searchType = ui->comboBox_searchType->currentText(); // Получаем выбранный тип поиска
    QString firstName = ui->lineEdit_firstName->text(); // Получаем введенное имя
    QString lastName = ui->lineEdit_lastName->text(); // Получаем введенную фамилию

        // Проверка на пустое значение
        if (firstName.isEmpty() || lastName.isEmpty()) {
            QMessageBox::warning(this, "Ошибка", "Пожалуйста, введите имя и фамилию.");
            return;
        }

        QSqlQuery query(db);
        QSqlQueryModel *model = new QSqlQueryModel(this); // Создаем модель один раз

        if (searchType == "Сотрудник") {
            // Поиск счетов, прикрепленных к сотруднику по имени и фамилии
            query.prepare("SELECT invoices.InvoiceId, invoices.InvoiceDate, invoices.BillingAddress, invoices.BillingCity "
                                  "FROM invoices "
                                  "JOIN customers ON invoices.CustomerId = customers.CustomerId "
                                  "JOIN employees ON customers.SupportRepId = employees.EmployeeId "
                                  "WHERE employees.FirstName = :firstName AND employees.LastName = :lastName");
        } else if (searchType == "Клиент") {
            // Поиск счетов, прикрепленных к клиенту по имени и фамилии
            query.prepare("SELECT invoices.InvoiceId, invoices.InvoiceDate, invoices.BillingAddress, invoices.BillingCity "
                          "FROM customers "
                          "JOIN invoices ON customers.CustomerId = invoices.CustomerId "
                          "WHERE customers.FirstName = :firstName AND customers.LastName = :lastName");
        } else {
            QMessageBox::warning(this, "Ошибка", "Неизвестный тип поиска.");
            return;
        }

        query.bindValue(":firstName", firstName);
        query.bindValue(":lastName", lastName);

        // Выполнение запроса
        if (query.exec()) {
            model->setQuery(query);
            if (model->rowCount() == 0) {
                QMessageBox::information(this, "Результаты", "Нет результатов для отображения.");
            } else {
                ui->tableView_invoices->setModel(model);
            }
        } else {
            QMessageBox::warning(this, "Ошибка", "Не удалось выполнить запрос: " + query.lastError().text());
        }
}

void find_emp::on_pushButton_2_clicked()
{
    hide();
    delete ui;
}
