#include "statistics_cities.h"
#include "ui_statistics_cities.h"
#include <QVBoxLayout>
#include <QWidget>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
#include <QVector>
#include <QMap>
#include <algorithm>

#include "qcustomplot.h"

statistics_cities::statistics_cities(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::statistics_cities)
{
    ui->setupUi(this);
    openDatabase("/Users/test/Documents/Qt/DataBaseWidget/chinook.db");
    setWindowTitle("Распределение клиентов по городам");
    setGeometry(100, 100, 800, 600);

    QCustomPlot *customPlot = new QCustomPlot(this);
    QVBoxLayout *layout = new QVBoxLayout(this);
    layout->addWidget(customPlot);
    setLayout(layout);

    QMap<QString, int> cityCounts;
    QSqlQuery query("SELECT City, COUNT(*) as Count FROM customers GROUP BY City", db);
    if (query.exec()) {
        while (query.next()) {
            QString city = query.value(0).toString();
            int count = query.value(1).toInt();
            cityCounts[city] = count;
        }
    } else {
        qDebug() << "Ошибка выполнения запроса:" << query.lastError().text();
    }

    // Подготовка данных для графика
    QVector<double> x;
    QVector<double> y;

    int index = 0;
    for (const QString &city : cityCounts.keys()) {
        x.push_back(index);
        y.push_back(cityCounts[city]);
        index++;
    }

    // Настройка осей
    customPlot->xAxis->setLabel("Города");
    customPlot->yAxis->setLabel("Количество клиентов");
    customPlot->xAxis->setTickLabelRotation(30);

    // Создание графика
    QCPGraph *graph = customPlot->addGraph();
    graph->setPen(QPen(Qt::blue)); // Цвет точек
    graph->setLineStyle(QCPGraph::lsNone); // Убираем линии между точками
    graph->setScatterStyle(QCPScatterStyle(QCPScatterStyle::ssCircle, 5)); // Устанавливаем стиль точек (круги размером 5)

    graph->setData(x, y); // Устанавливаем данные для графика

    customPlot->xAxis->setRange(-1, cityCounts.size()); // Устанавливаем диапазон для оси X
    customPlot->yAxis->setRange(0, *std::max_element(y.begin(), y.end()) + 1); // Устанавливаем диапазон для оси Y

    // Обновляем график
    customPlot->replot();
}

statistics_cities::~statistics_cities()
{
    db.close();
    delete ui;
}

void statistics_cities::openDatabase(const QString &dbPath)
{
    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName(dbPath);

    if (!db.open()) {
        printf("Ошибка открытия базы данных");
    }
}
