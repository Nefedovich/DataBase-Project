#include "statistics.h"
#include "ui_statistics.h"

statistics::statistics(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::statistics)
{
    ui->setupUi(this);
}

statistics::~statistics()
{
    delete ui;
}

void statistics::on_pushButton_clicked()
{
    stct = new statistics_cities;
    stct->show();
}


void statistics::on_pushButton_2_clicked()
{
    stg = new statictics_genres;
    stg->show();
}


void statistics::on_pushButton_4_clicked()
{
    stpl = new statistics_playlist;
    stpl->show();
}

