#include "new_invoices_bd.h"
#include "ui_new_invoices_bd.h"

new_invoices_bd::new_invoices_bd(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::new_invoices_bd)
{
    ui->setupUi(this);
    openDatabase("/Users/test/Documents/Qt/DataBaseWidget/chinook.db");
}

new_invoices_bd::~new_invoices_bd()
{
    db.close();
    delete ui;
}

void new_invoices_bd::on_pushButton_2_clicked()
{
    hide();
    delete ui;
}

void new_invoices_bd::openDatabase(const QString &dbPath)
{
    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName(dbPath);

    if (!db.open()) {
        printf("Ошибка открытия базы данных");
    }
}

void new_invoices_bd::on_pushButton_clicked()
{
    QString CustomerId = ui->lineEdit->text();
    QString InvoiceDate = ui->lineEdit_2->text();
    QString BillingAdress = ui->lineEdit_3->text();
    QString BillingCity = ui->lineEdit_4->text();

    if (InvoiceDate.isEmpty() || CustomerId.isEmpty() || BillingAdress.isEmpty() || BillingCity.isEmpty()) {
        QMessageBox::warning(this, "Ошибка", "Пожалуйста, заполните все поля.");
        return;
    }
    bool isNumeric;
    int cId = CustomerId.toInt(&isNumeric);
    if (!isNumeric || cId <= 0) {
        QMessageBox::warning(this, "Ошибка", "ID должен быть числом больше нуля.");
        return;
    }

    QSqlQuery checkCustomerQuery(db);
    checkCustomerQuery.prepare("SELECT 1 FROM customers WHERE CustomerId = :Id");
    checkCustomerQuery.bindValue(":Id", cId);
    if (!checkCustomerQuery.exec() || !checkCustomerQuery.next()) {
        QMessageBox::warning(this, "Ошибка", "ID сотрудника не существует.");
        return;
    }

     QSqlQuery query(db);
     query.prepare("INSERT INTO invoices (CustomerId, InvoiceDate, BillingAddress, BillingCity) VALUES (:custId, :date, :adress, :city)");
     query.bindValue(":custId", cId);
     query.bindValue(":date", InvoiceDate);
     query.bindValue(":adress", BillingAdress);
     query.bindValue(":city", BillingCity);

     if (!query.exec()) {
         qDebug() << "Ошибка при добавлении:" << query.lastError().text();
         QMessageBox::critical(this, "Ошибка", "Не удалось добавить строку в базу данных.");
     } else {
         qDebug() << "Строка успешно добавлена!";
         QMessageBox::information(this, "Успех", "Строка успешно добавлена!");
         close();
     }
}
