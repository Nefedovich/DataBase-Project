#include "stat_employee_sale.h"
#include "ui_stat_employee_sale.h"

#include <QVBoxLayout>
#include <QDebug>
#include <QSqlQuery>
#include <QSqlError>
#include <QMap>
#include <QVector>
#include <algorithm>
#include "qcustomplot.h"

stat_employee_sale::stat_employee_sale(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::stat_employee_sale)
{
    ui->setupUi(this);
    openDatabase("/Users/test/Documents/Qt/DataBaseWidget/chinook.db");
    setWindowTitle("Распределение сотрудников по количеству продаж");
    setGeometry(100, 100, 800, 600);

    QCustomPlot *customPlot = new QCustomPlot(this);
    QVBoxLayout *layout = new QVBoxLayout(this);
    layout->addWidget(customPlot);
    setLayout(layout);

    QMap<QString, int> salesCounts;

    // Запрос для получения количества продаж по каждому сотруднику
    QSqlQuery query("SELECT e.EmployeeId, COUNT(i.InvoiceId) AS SalesCount "
                    "FROM employees e "
                    "LEFT JOIN customers c ON e.EmployeeId = c.SupportRepId "
                    "LEFT JOIN invoices i ON c.CustomerId = i.CustomerId "
                    "GROUP BY e.EmployeeId "
                    "ORDER BY SalesCount DESC;", db);

    if (query.exec()) {
        while (query.next()) {
            QString employeeId = query.value(0).toString(); // Получаем EmployeeId
            int salesCount = query.value(1).toInt(); // Получаем количество продаж
            salesCounts[employeeId] = salesCount; // Сохраняем количество продаж по ID сотрудника
        }
    } else {
        qDebug() << "Ошибка выполнения запроса:" << query.lastError().text();
    }

    // Подготовка данных для графика
    QVector<double> x;
    QVector<double> y;

    int index = 0;
    for (const QString &employeeId : salesCounts.keys()) {
        x.push_back(index);
        y.push_back(salesCounts[employeeId]);
        index++;
    }

    // Настройка осей
    customPlot->xAxis->setLabel("Сотрудник (ID)");
    customPlot->yAxis->setLabel("Количество продаж");
    customPlot->xAxis->setTickLabelRotation(30); // Поворот меток по оси X

    // Создание графика
    QCPGraph *graph = customPlot->addGraph();
    graph->setPen(QPen(Qt::blue)); // Цвет точек
    graph->setLineStyle(QCPGraph::lsNone); // Убираем линии между точками
    graph->setScatterStyle(QCPScatterStyle(QCPScatterStyle::ssCircle, 5)); // Устанавливаем стиль точек (круги размером 5)

    graph->setData(x, y); // Устанавливаем данные для графика

    customPlot->xAxis->setRange(-1, salesCounts.size()); // Устанавливаем диапазон для оси X
    customPlot->yAxis->setRange(0, *std::max_element(y.begin(), y.end()) + 1); // Устанавливаем диапазон для оси Y

    // Обновляем график
    customPlot->replot();
}

stat_employee_sale::~stat_employee_sale()
{
    db.close(); // Закрываем соединение с БД
    delete ui;
}

void stat_employee_sale::openDatabase(const QString &dbPath)
{
    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName(dbPath);

    if (!db.open()) {
        qDebug() << "Ошибка открытия базы данных";
    }
}
