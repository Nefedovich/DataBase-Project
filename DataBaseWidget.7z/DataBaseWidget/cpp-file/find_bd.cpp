#include "find_bd.h"
#include "ui_find_bd.h"
#include <QSqlQuery>
#include <QSqlQueryModel>
#include <QMessageBox>
#include <QSqlError>

find_bd::find_bd(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::find_bd)
{
    ui->setupUi(this);
    openDatabase("/Users/test/Documents/Qt/DataBaseWidget/chinook.db");

    ui->comboBox_searchType->addItem("Исполнитель");
    ui->comboBox_searchType->addItem("Альбом");
    ui->comboBox_searchType->addItem("Жанр");
    ui->comboBox_searchType->addItem("Тип медиа");
    connect(ui->comboBox_searchType, SIGNAL(currentIndexChanged(int)), this, SLOT(on_comboBox_searchType_currentIndexChanged(int)));
    connect(ui->pushButton_search, SIGNAL(clicked()), this, SLOT(on_pushButton_search_clicked()));
}

find_bd::~find_bd()
{
    db.close();
    delete ui;
}

void find_bd::openDatabase(const QString &dbPath)
{

    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName(dbPath);

    if (!db.open()) {
        printf("Ошибка открытия базы данных");
    }
}

void find_bd::on_comboBox_searchType_currentIndexChanged(int index)
{
    populateSearchValues();
}

void find_bd::populateSearchValues()
{
    ui->comboBox_searchValue->clear();
    QString searchType = ui->comboBox_searchType->currentText();

    if (searchType == "Исполнитель") {
        QSqlQuery query("SELECT Name FROM artists");
        while (query.next()) {
            ui->comboBox_searchValue->addItem(query.value(0).toString());
        }
    } else if (searchType == "Альбом") {
        QSqlQuery query("SELECT Title FROM albums");
        while (query.next()) {
            ui->comboBox_searchValue->addItem(query.value(0).toString());
        }
    } else if (searchType == "Жанр") {
            QSqlQuery query("SELECT Name FROM genres");
            while (query.next()) {
                ui->comboBox_searchValue->addItem(query.value(0).toString());
            }
        }
    else if (searchType == "Тип медиа") {
                QSqlQuery query("SELECT Name FROM media_types");
                while (query.next()) {
                    ui->comboBox_searchValue->addItem(query.value(0).toString());
                }
            }
}

void find_bd::on_pushButton_search_clicked()
{
    search();
}

void find_bd::search()
{
    QString searchType = ui->comboBox_searchType->currentText();
    QString searchValue = ui->comboBox_searchValue->currentText();

    // Проверка на пустое значение
    if (searchValue.isEmpty()) {
        QMessageBox::warning(this, "Ошибка", "Пожалуйста, выберите значение для поиска.");
        return;
    }

    QSqlQuery query(db);
    QSqlQueryModel *model = new QSqlQueryModel(this); // Создаем модель один раз

    if (searchType == "Исполнитель") {
        query.prepare("SELECT albums.Title AS AlbumTitle, tracks.Name AS TrackName "
                      "FROM artists "
                      "JOIN albums ON artists.ArtistId = albums.ArtistId "
                      "JOIN tracks ON albums.AlbumId = tracks.AlbumId "
                      "WHERE artists.Name = :artistName");
        query.bindValue(":artistName", searchValue);
    } else if (searchType == "Альбом") {
        query.prepare("SELECT artists.Name AS ArtistName, tracks.Name AS TrackName "
                      "FROM albums "
                      "JOIN artists ON albums.ArtistId = artists.ArtistId "
                      "JOIN tracks ON albums.AlbumId = tracks.AlbumId "
                      "WHERE albums.Title = :albumTitle");
        query.bindValue(":albumTitle", searchValue);
    } else if (searchType == "Жанр") {
        query.prepare("SELECT artists.Name AS ArtistName, albums.Title AS AlbumTitle, tracks.Name AS TrackName "
                      "FROM genres "
                      "JOIN tracks ON genres.GenreId = tracks.GenreId "
                      "JOIN albums ON tracks.AlbumId = albums.AlbumId "
                      "JOIN artists ON albums.ArtistId = artists.ArtistId "
                      "WHERE genres.Name = :genreName");
        query.bindValue(":genreName", searchValue);
    }
    else if (searchType == "Тип медиа") {
            query.prepare("SELECT artists.Name AS ArtistName, albums.Title AS AlbumTitle, tracks.Name AS TrackName "
                          "FROM media_types "
                          "JOIN tracks ON media_types.MediaTypeId = tracks.MediaTypeId "
                          "JOIN albums ON tracks.AlbumId = albums.AlbumId "
                          "JOIN artists ON albums.ArtistId = artists.ArtistId "
                          "WHERE media_types.Name = :mediaTypeName");
            query.bindValue(":mediaTypeName", searchValue);
        }
    else {
        QMessageBox::warning(this, "Ошибка", "Неизвестный тип поиска.");
        return;
    }

    // Выполнение запроса
    if (query.exec()) {
        model->setQuery(query);
        if (model->rowCount() == 0) {
            QMessageBox::information(this, "Результаты", "Нет результатов для отображения.");
        }
        ui->tableView_results->setModel(model);
    } else {
        QMessageBox::warning(this, "Ошибка", "Не удалось выполнить запрос: " + query.lastError().text());
    }
}


void find_bd::on_pushButton_2_clicked()
{
    hide();
    delete ui;
}
