#include "new_albums.h"
#include "ui_new_albums.h"
#include <QSqlQuery>
#include <QSqlQueryModel>

new_albums::new_albums(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::new_albums)
{
    ui->setupUi(this);
    openDatabase("/Users/test/Documents/Qt/DataBaseWidget/chinook.db");
}

new_albums::~new_albums()
{
    db.close();
    delete ui;
}

void new_albums::openDatabase(const QString &dbPath)
{
    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName(dbPath);

    if (!db.open()) {
        printf("Ошибка открытия базы данных");
    }
}

void new_albums::on_pushButton_2_clicked()
{
    hide();
    delete ui;
}

void new_albums::on_pushButton_clicked()
{
    QString value1 = ui->lineEdit->text();
    QString value2 = ui->lineEdit_2->text();

    if (value1.isEmpty() || value2.isEmpty()) {
        QMessageBox::warning(this, "Ошибка", "Пожалуйста, заполните все поля.");
        return;
    }
    bool isNumeric;
    int artistId = value2.toInt(&isNumeric);
    if (!isNumeric || artistId <= 0) {
        QMessageBox::warning(this, "Ошибка", "ID исполнителя должен быть числом больше нуля.");
        return;
    }

    QSqlQuery checkArtistQuery(db);
    checkArtistQuery.prepare("SELECT 1 FROM artists WHERE ArtistId = :Id");
    checkArtistQuery.bindValue(":Id", artistId);
    if (!checkArtistQuery.exec() || !checkArtistQuery.next()) {
        QMessageBox::warning(this, "Ошибка", "ID сотрудника не существует.");
        return;
    }

     QSqlQuery query(db);
     query.prepare("INSERT INTO albums (Title, ArtistId) VALUES (:title, :artistId)");
     query.bindValue(":title", value1);
     query.bindValue(":artistId", artistId);

     if (!query.exec()) {
         qDebug() << "Ошибка при добавлении альбома:" << query.lastError().text();
         QMessageBox::critical(this, "Ошибка", "Не удалось добавить альбом в базу данных.");
     } else {
         qDebug() << "Альбом успешно добавлен!";
         QMessageBox::information(this, "Успех", "Альбом успешно добавлен!");
         close(); // Закрываем форму после успешного добавления
     }
}
