#include "new_playlist.h"
#include "ui_new_playlist.h"
#include <QSqlQuery>
#include <QSqlQueryModel>

new_playlist::new_playlist(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::new_playlist)
{
    ui->setupUi(this);
    openDatabase("/Users/test/Documents/Qt/DataBaseWidget/chinook.db");
    ui->comboBox_searchType->addItem("Исполнитель");
    ui->comboBox_searchType->addItem("Альбом");
    ui->comboBox_searchType->addItem("Жанр");
    connect(ui->comboBox_searchType, SIGNAL(currentIndexChanged(int)), this, SLOT(on_comboBox_searchType_currentIndexChanged(int)));
    connect(ui->pushButton_search, SIGNAL(clicked()), this, SLOT(on_pushButton_search_clicked()));
}

new_playlist::~new_playlist()
{
    db.close();
    delete ui;
}

void new_playlist::openDatabase(const QString &dbPath)
{
    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName(dbPath);

    if (!db.open()) {
        printf("Ошибка открытия базы данных");
    }
}

void new_playlist::on_pushButton_2_clicked()
{
    hide();
    delete ui;
}

void new_playlist::on_pushButton_clicked()
{
    QString value1 = ui->lineEdit->text();

    if (value1.isEmpty()) {
        QMessageBox::warning(this, "Ошибка", "Пожалуйста, заполните поле.");
        return;
    }

     QSqlQuery query(db);
     query.prepare("INSERT INTO playlists (Name) VALUES (:name)");
     query.bindValue(":name", value1);


     if (!query.exec()) {
         qDebug() << "Ошибка при добавлении плейлиста:" << query.lastError().text();
         QMessageBox::critical(this, "Ошибка", "Не удалось добавить плейлист в базу данных.");
     } else {
         qDebug() << "Плейлист успешно добавлен!";
         QMessageBox::information(this, "Успех", "Плейлист успешно добавлен!");
         close();
     }
}


void new_playlist::on_comboBox_searchType_currentIndexChanged(int index)
{
    populateSearchValues();
}

void new_playlist::populateSearchValues()
{
    ui->comboBox_searchValue->clear();
    QString searchType = ui->comboBox_searchType->currentText();

    if (searchType == "Исполнитель") {
        QSqlQuery query("SELECT Name FROM artists");
        while (query.next()) {
            ui->comboBox_searchValue->addItem(query.value(0).toString());
        }
    } else if (searchType == "Альбом") {
        QSqlQuery query("SELECT Title FROM albums");
        while (query.next()) {
            ui->comboBox_searchValue->addItem(query.value(0).toString());
        }
    } else if (searchType == "Жанр") {
            QSqlQuery query("SELECT Name FROM genres");
            while (query.next()) {
                ui->comboBox_searchValue->addItem(query.value(0).toString());
            }
        }
}

void new_playlist::on_pushButton_search_clicked()
{
    search();
}

void new_playlist::search()
{
    QString searchType = ui->comboBox_searchType->currentText();
    QString searchValue = ui->comboBox_searchValue->currentText();

    // Проверка на пустое значение
    if (searchValue.isEmpty()) {
        QMessageBox::warning(this, "Ошибка", "Пожалуйста, выберите значение для поиска.");
        return;
    }

    QSqlQuery query(db);
    QSqlQueryModel *model = new QSqlQueryModel(this); // Создаем модель один раз

    if (searchType == "Исполнитель") {
        query.prepare("SELECT tracks.TrackId, albums.Title AS AlbumTitle, tracks.Name AS TrackName "
                      "FROM artists "
                      "JOIN albums ON artists.ArtistId = albums.ArtistId "
                      "JOIN tracks ON albums.AlbumId = tracks.AlbumId "
                      "WHERE artists.Name = :artistName");
        query.bindValue(":artistName", searchValue);
    } else if (searchType == "Альбом") {
        query.prepare("SELECT tracks.TrackId, artists.Name AS ArtistName, tracks.Name AS TrackName "
                      "FROM albums "
                      "JOIN artists ON albums.ArtistId = artists.ArtistId "
                      "JOIN tracks ON albums.AlbumId = tracks.AlbumId "
                      "WHERE albums.Title = :albumTitle");
        query.bindValue(":albumTitle", searchValue);
    } else if (searchType == "Жанр") {
        query.prepare("SELECT tracks.TrackId, artists.Name AS ArtistName, albums.Title AS AlbumTitle, tracks.Name AS TrackName "
                      "FROM genres "
                      "JOIN tracks ON genres.GenreId = tracks.GenreId "
                      "JOIN albums ON tracks.AlbumId = albums.AlbumId "
                      "JOIN artists ON albums.ArtistId = artists.ArtistId "
                      "WHERE genres.Name = :genreName");
        query.bindValue(":genreName", searchValue);
    }
    else {
        QMessageBox::warning(this, "Ошибка", "Неизвестный тип поиска.");
        return;
    }

    // Выполнение запроса
    if (query.exec()) {
        model->setQuery(query);
        if (model->rowCount() == 0) {
            QMessageBox::information(this, "Результаты", "Нет результатов для отображения.");
        }
        ui->tableView_results->setModel(model);
    } else {
        QMessageBox::warning(this, "Ошибка", "Не удалось выполнить запрос: " + query.lastError().text());
    }
}

void new_playlist::on_pushButton_3_clicked()
{
    QString value1 = ui->lineEdit_2->text();

    if (value1.isEmpty()) {
        QMessageBox::warning(this, "Ошибка", "Пожалуйста, заполните поле.");
        return;
    }

    bool isNumeric;
    int tId = value1.toInt(&isNumeric);
    if (!isNumeric || tId <= 0) {
        QMessageBox::warning(this, "Ошибка", "ID трека должен быть числом больше нуля.");
        return;
    }

    QSqlQuery checkTrackQuery(db);
    checkTrackQuery.prepare("SELECT 1 FROM tracks WHERE TrackId = :trackId");
    checkTrackQuery.bindValue(":trackId", tId);
    if (!checkTrackQuery.exec() || !checkTrackQuery.next()) {
        QMessageBox::warning(this, "Ошибка", "ID трека не существует.");
        return;
    }

    QString playlistName = ui->lineEdit->text();
    int playlistId = -1; // Инициализируем переменную для хранения идентификатора плейлиста
    QSqlQuery query2(db);
    query2.prepare("SELECT PlaylistId FROM playlists WHERE Name = :playlistName");
    query2.bindValue(":playlistName", playlistName);

    if (query2.exec()) {
        if (query2.next()) { // Если найдена хотя бы одна запись
            playlistId = query2.value(0).toInt(); // Сохраняем идентификатор плейлиста
        } else {
            QMessageBox::information(nullptr, "Результаты", "Плейлист не найден.");
          }
    } else {
      QMessageBox::warning(nullptr, "Ошибка", "Не удалось выполнить запрос: " + query2.lastError().text());
    }

     QSqlQuery query(db);
     query.prepare("INSERT INTO playlist_track (PlayListId, TrackId) VALUES (:playlistid, :trackid)");
     query.bindValue(":trackid", value1);
     query.bindValue(":playlistid", playlistId);


     if (!query.exec()) {
         qDebug() << "Ошибка при добавлении плейлиста:" << query.lastError().text();
         QMessageBox::critical(this, "Ошибка", "Не удалось добавить плейлист в базу данных.");
     } else {
         qDebug() << "Плейлист успешно добавлен!";
         QMessageBox::information(this, "Успех", "Плейлист успешно добавлен!");
         close();
     }
}

void new_playlist::on_pushButton_4_clicked()
{
    hide();
    delete ui;
}
