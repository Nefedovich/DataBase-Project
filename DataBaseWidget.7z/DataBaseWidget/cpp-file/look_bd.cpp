#include "look_bd.h"
#include "ui_look_bd.h"
#include <QSqlQuery>
#include <QSqlQueryModel>

look_bd::look_bd(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::look_bd)
{
    ui->setupUi(this);
    connect(ui->tableSelector, &QComboBox::currentTextChanged, this, &look_bd::onTableChanged);
    openDatabase("/Users/test/Documents/Qt/DataBaseWidget/chinook.db");
    loadTable(ui->tableSelector->currentText());
}

look_bd::~look_bd()
{
    db.close();
    delete ui;
}

void look_bd::openDatabase(const QString &dbPath)
{
    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName(dbPath);

    if (!db.open()) {
        printf("Ошибка открытия базы данных");
    }
}

void look_bd::loadTable(const QString &tableName)
{
    QSqlQueryModel *model = new QSqlQueryModel(this);
    QSqlQuery query(db);

    query.prepare(QString("SELECT * FROM %1").arg(tableName));

    if (!query.exec()) {
        printf("Ошибка выполнения запроса");
        return;
    }

    model->setQuery(query);
    ui->tableView->setModel(model);
}


void look_bd::onTableChanged(const QString &tableName)
{
    loadTable(tableName);
}
