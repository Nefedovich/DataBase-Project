#include "statistics_playlist.h"
#include "ui_statistics_playlist.h"

#include <QVBoxLayout>
#include <QWidget>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
#include <QVector>
#include <QMap>
#include <algorithm>

#include "qcustomplot.h"

statistics_playlist::statistics_playlist(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::statistics_playlist)
{
    ui->setupUi(this);
    openDatabase("/Users/test/Documents/Qt/DataBaseWidget/chinook.db");
    playlistValues();
}

statistics_playlist::~statistics_playlist()
{
    db.close();
    delete ui;
}

void statistics_playlist::playlistValues()
{
    ui->comboBox->clear();

    QSqlQuery query("SELECT Name FROM playlists");
    while (query.next()) {
        ui->comboBox->addItem(query.value(0).toString());
    }
}

void statistics_playlist::openDatabase(const QString &dbPath)
{
    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName(dbPath);

    if (!db.open()) {
        printf("Ошибка открытия базы данных");
    }
}

void statistics_playlist::on_pushButton_clicked()
{
    setWindowTitle("Распределение треков в плейлисте по жанру");
    setGeometry(100, 100, 800, 600);

    QCustomPlot *customPlot = new QCustomPlot(this);
    QVBoxLayout *layout = new QVBoxLayout(this);
    layout->addWidget(customPlot);
    setLayout(layout);

    QMap<QString, int> genreCounts;
    QString name = ui->comboBox->currentText();
    QString id;

    QSqlQuery query1(db);
    query1.prepare("SELECT playlists.PlaylistId FROM playlists WHERE playlists.Name = :name");
    query1.bindValue(":name", name);

    if (query1.exec()) {
        if (query1.next()) {
            id = query1.value(0).toString();
        } else {
            qDebug() << "Плейлист с таким именем не найден.";
            return; // Если плейлист не найден, выходим из функции
        }
    } else {
        qDebug() << "Ошибка выполнения запроса:" << query1.lastError().text();
        return; // Если ошибка выполнения запроса, выходим из функции
    }

    // Выполнение второго запроса
    QSqlQuery query(db);
    query.prepare("SELECT t.GenreId, COUNT(*) as Count "
                  "FROM tracks t "
                  "JOIN playlist_track pt ON t.TrackId = pt.TrackId "
                  "WHERE pt.PlaylistId = :playlistId "
                  "GROUP BY t.GenreId");
    query.bindValue(":playlistId", id);

    if (query.exec()) {
        while (query.next()) {
            QString genre = query.value(0).toString();
            int count = query.value(1).toInt();
            genreCounts[genre] = count;
        }
    } else {
        qDebug() << "Ошибка выполнения запроса:" << query.lastError().text();
        return; // Если ошибка выполнения запроса, выходим из функции
    }

    if (query.exec()) {
        while (query.next()) {
            QString genre = query.value(0).toString();
            int count = query.value(1).toInt();
            genreCounts[genre] = count;
        }
    } else {
        qDebug() << "Ошибка выполнения запроса:" << query.lastError().text();
        return;
    }
    QVector<double> x;
    QVector<double> y;

    int index = 0;
    for (const QString &city : genreCounts.keys()) {
        x.push_back(index);
        y.push_back(genreCounts[city]);
        index++;
    }

    customPlot->xAxis->setLabel("Города");
    customPlot->yAxis->setLabel("Количество клиентов");
    customPlot->xAxis->setTickLabelRotation(30);

    QCPGraph *graph = customPlot->addGraph();
    graph->setPen(QPen(Qt::blue));
    graph->setLineStyle(QCPGraph::lsNone);
    graph->setScatterStyle(QCPScatterStyle(QCPScatterStyle::ssCircle, 5));
    graph->setData(x, y);

    customPlot->xAxis->setRange(-1, genreCounts.size());
    customPlot->yAxis->setRange(0, *std::max_element(y.begin(), y.end()) + 100);
    customPlot->replot();
}

